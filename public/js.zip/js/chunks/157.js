(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[157],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/staff/roles.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/staff/roles.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _axios_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../axios.js */ "./resources/js/src/axios.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      user_id: "",
      allPermission: [],
      staffData: {
        user: ""
      },
      permission_check: [],
      user_permission: [],
      allStaff: [],
      searchQuery: "",
      permissions: []
    };
  },
  watch: {},
  computed: {
    application_id: function application_id() {
      return this.$store.state.application_id;
    }
  },
  mounted: function mounted() {
    this.getAllStaff();
    this.getPermission();
  },
  methods: {
    getAllStaff: function getAllStaff() {
      var _this = this;

      _axios_js__WEBPACK_IMPORTED_MODULE_0__["default"].get("/api/allStaff").then(function (res) {
        _this.allStaff = res.data.data;
      }).catch(function (err) {
        console.log(err);
      });
    },
    getPermission: function getPermission() {
      var _this2 = this;

      _axios_js__WEBPACK_IMPORTED_MODULE_0__["default"].get("/api/permission").then(function (res) {
        _this2.allPermission = res.data.data;
        localStorage.setItem("allpermission", JSON.stringify(_this2.allPermission));
        console.log("permistions : ", _this2.allPermission);
      }).catch(function (err) {
        console.log(err);
      });
    },
    getUserPermission: function getUserPermission() {
      var _this3 = this;

      _axios_js__WEBPACK_IMPORTED_MODULE_0__["default"].get("/api/userPermission/show/" + this.user_id).then(function (res) {
        _this3.user_permission = res.data.data;
        console.log("permission", _this3.user_permission);
      }).catch(function (err) {
        console.log(err);
      });
    },
    submitData: function submitData() {
      var _this4 = this;

      if (this.user_id) {
        this.user_permission.forEach(function (permission_id, index) {
          if (permission_id) {
            _this4.permissions.push({
              user_id: _this4.user_id,
              permission_id: _this4.allPermission[index].id
            });
          }
        });
        _axios_js__WEBPACK_IMPORTED_MODULE_0__["default"].post("/api/userPermission/" + this.user_id, this.permissions).then(function (res) {
          _this4.showSuccess();
        }).catch(function (err) {
          console.log(err);
        });
      } else {
        this.showError();
      }
    },
    showSuccess: function showSuccess() {
      this.$vs.notify({
        color: "success",
        title: "permission is added successfully",
        text: "permission is added successfully"
      });
    },
    showError: function showError() {
      this.$vs.notify({
        color: "danger",
        title: "must choose user",
        text: "must choose user first"
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/staff/roles.vue?vue&type=template&id=592080b4&":
/*!*************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/staff/roles.vue?vue&type=template&id=592080b4& ***!
  \*************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c(
      "div",
      { attrs: { "bg-white": "" } },
      [
        _c("div", { staticClass: "vs-row flex" }, [
          _c("div", { staticClass: "w-1/4 mb-6" }, [
            _c(
              "div",
              { staticClass: "search-page__search-bar flex items-center" },
              [
                _c("vs-input", {
                  staticClass: "w-full input-rounded-full p-5",
                  attrs: {
                    name: "Roles",
                    "icon-no-border": "",
                    placeholder: "Search",
                    icon: "icon-search",
                    "icon-pack": "feather"
                  }
                })
              ],
              1
            )
          ])
        ]),
        _vm._v(" "),
        _c(
          "vx-card",
          [
            _c("div", { staticClass: "vx-row p-5" }, [
              _c("h3", [_vm._v("add staff permissions")])
            ]),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "vx-row" },
              [
                _c(
                  "vs-select",
                  {
                    directives: [
                      {
                        name: "validate",
                        rawName: "v-validate",
                        value: "required",
                        expression: "'required'"
                      }
                    ],
                    staticClass: "selectExample w-1/2 p-5",
                    attrs: { label: "choose staff name" },
                    on: {
                      input: function($event) {
                        return _vm.getUserPermission()
                      }
                    },
                    model: {
                      value: _vm.user_id,
                      callback: function($$v) {
                        _vm.user_id = $$v
                      },
                      expression: "user_id"
                    }
                  },
                  _vm._l(_vm.allStaff, function(item, index) {
                    return _c("vs-select-item", {
                      key: index,
                      attrs: { value: item.id, text: item.name }
                    })
                  }),
                  1
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "vx-card",
              { staticClass: "w-1/2 ml-outo" },
              [
                _vm._l(_vm.allPermission, function(item, index) {
                  return _c(
                    "div",
                    { key: index, staticClass: "py-3" },
                    [
                      _c(
                        "vs-checkbox",
                        {
                          attrs: { value: item.id },
                          model: {
                            value: _vm.user_permission[index],
                            callback: function($$v) {
                              _vm.$set(_vm.user_permission, index, $$v)
                            },
                            expression: "user_permission[index]"
                          }
                        },
                        [_vm._v(_vm._s(item.name))]
                      )
                    ],
                    1
                  )
                }),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "row" },
                  [
                    _c(
                      "vs-button",
                      {
                        on: {
                          click: function($event) {
                            return _vm.submitData()
                          }
                        }
                      },
                      [_vm._v("submit")]
                    )
                  ],
                  1
                )
              ],
              2
            )
          ],
          1
        )
      ],
      1
    )
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/staff/roles.vue":
/*!************************************************!*\
  !*** ./resources/js/src/views/staff/roles.vue ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _roles_vue_vue_type_template_id_592080b4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./roles.vue?vue&type=template&id=592080b4& */ "./resources/js/src/views/staff/roles.vue?vue&type=template&id=592080b4&");
/* harmony import */ var _roles_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./roles.vue?vue&type=script&lang=js& */ "./resources/js/src/views/staff/roles.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _roles_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _roles_vue_vue_type_template_id_592080b4___WEBPACK_IMPORTED_MODULE_0__["render"],
  _roles_vue_vue_type_template_id_592080b4___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/staff/roles.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/staff/roles.vue?vue&type=script&lang=js&":
/*!*************************************************************************!*\
  !*** ./resources/js/src/views/staff/roles.vue?vue&type=script&lang=js& ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_roles_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./roles.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/staff/roles.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_roles_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/staff/roles.vue?vue&type=template&id=592080b4&":
/*!*******************************************************************************!*\
  !*** ./resources/js/src/views/staff/roles.vue?vue&type=template&id=592080b4& ***!
  \*******************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_roles_vue_vue_type_template_id_592080b4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./roles.vue?vue&type=template&id=592080b4& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/staff/roles.vue?vue&type=template&id=592080b4&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_roles_vue_vue_type_template_id_592080b4___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_roles_vue_vue_type_template_id_592080b4___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);