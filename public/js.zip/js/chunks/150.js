(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[150],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/field/add.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/field/add.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _axios_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../axios.js */ "./resources/js/src/axios.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  name: "imageUpload",
  data: function data() {
    return {
      applicationFields: [],
      applications: [],
      products: [],
      companies: [],
      previewImage: null,
      programs: [],
      roles: [],
      users: [],
      searchQuery: "",
      fieldData: {
        name: "",
        name_ar: "",
        type: "",
        items: []
      }
    };
  },
  watch: {
    application_id: function application_id(val) {}
  },
  mounted: function mounted() {},
  created: function created() {
    this.getCreatedData();
  },
  computed: {
    application_id: function application_id() {
      return this.$store.state.application_id;
    }
  },
  methods: {
    getCreatedData: function getCreatedData() {
      var _this = this;

      _axios_js__WEBPACK_IMPORTED_MODULE_0__["default"].get('/api/field/create').then(function (res) {
        _this.roles = res.data.roles;
      });
    },
    addSubcategory: function addSubcategory() {
      this.applicationFields.push({
        name: ""
      });
    },
    removeSubcategory: function removeSubcategory(index) {
      this.applicationFields.splice(index, 1);
    },
    submitData: function submitData() {
      var _this2 = this;

      this.fieldData.application_id = this.application_id;
      this.$validator.validateAll().then(function (res) {
        _axios_js__WEBPACK_IMPORTED_MODULE_0__["default"].post('/api/field', _this2.fieldData).then(function (res) {
          _this2.showSuccess("field has been created successfuly");

          setTimeout(function () {
            _this2.$router.push({
              name: 'fieldList'
            });
          }, 300);
        }).catch(function (err) {
          var errors = err.response.data.errors;
          Object.keys(errors).forEach(function (key) {
            _this2.showError(errors[key]);
          });
        });
      });
    },
    addItem: function addItem() {
      this.fieldData.items.push({});
    },
    removeItem: function removeItem(index) {
      this.fieldData.items.splice(index, 1);
    },
    showSuccess: function showSuccess(msg) {
      this.$vs.notify({
        color: "success",
        text: msg
      });
    },
    showError: function showError(msg) {
      this.$vs.notify({
        color: "danger",
        title: "Error",
        text: msg,
        position: "top-center"
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/field/add.vue?vue&type=template&id=42fee872&":
/*!***********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/field/add.vue?vue&type=template&id=42fee872& ***!
  \***********************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "container" }, [
    _c("div", { staticClass: "vx-row" }, [
      _c("div", { staticClass: "vx-col w-full" }, [
        _c(
          "div",
          { staticClass: "search-page__search-bar flex items-center w-1/4" },
          [
            _c("vs-input", {
              staticClass: "w-full input-rounded-full",
              attrs: {
                "icon-no-border": "",
                placeholder: "Search",
                icon: "icon-search",
                "icon-pack": "feather"
              },
              model: {
                value: _vm.searchQuery,
                callback: function($$v) {
                  _vm.searchQuery = $$v
                },
                expression: "searchQuery"
              }
            })
          ],
          1
        )
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "vx-row mt-5 w-full" }, [
        _c(
          "div",
          { staticClass: "vx-col w-full md:w-full sm:w-full" },
          [
            _c("vx-card", [
              _c("div", { staticClass: "row px-3" }, [
                _c(
                  "h3",
                  { staticClass: "text-title-grey title-patient py-5" },
                  [_vm._v("New field")]
                ),
                _vm._v(" "),
                _c("h1", { staticClass: "my-3 text-title-grey" }, [
                  _vm._v("Add New field")
                ])
              ]),
              _vm._v(" "),
              _c(
                "div",
                { staticClass: "vx-row mb-2" },
                [
                  _c(
                    "div",
                    { staticClass: "vx-col w-1/2" },
                    [
                      _c("vs-input", {
                        staticClass: "w-full my-5",
                        attrs: {
                          type: "text",
                          "icon-pack": "feather",
                          icon: "icon-user",
                          "icon-no-border": "",
                          "label-placeholder": " Field Name"
                        },
                        model: {
                          value: _vm.fieldData.name,
                          callback: function($$v) {
                            _vm.$set(_vm.fieldData, "name", $$v)
                          },
                          expression: "fieldData.name"
                        }
                      })
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "vx-col w-1/2" },
                    [
                      _c("vs-input", {
                        staticClass: "w-full my-5",
                        attrs: {
                          type: "text",
                          "icon-pack": "feather",
                          icon: "icon-edit",
                          "icon-no-border": "",
                          "label-placeholder": "Name in Arabic",
                          name: "name_ar"
                        },
                        model: {
                          value: _vm.fieldData.name_ar,
                          callback: function($$v) {
                            _vm.$set(_vm.fieldData, "name_ar", $$v)
                          },
                          expression: "fieldData.name_ar"
                        }
                      }),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("name_ar"),
                              expression: "errors.has('name_ar')"
                            }
                          ],
                          staticClass: "text-danger text-sm"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("name_ar")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "vx-col w-1/2" },
                    [
                      _c(
                        "vs-select",
                        {
                          directives: [
                            {
                              name: "validate",
                              rawName: "v-validate",
                              value: "required",
                              expression: "'required'"
                            }
                          ],
                          staticClass: "w-full",
                          attrs: { name: "service_id", label: "type" },
                          model: {
                            value: _vm.fieldData.type,
                            callback: function($$v) {
                              _vm.$set(_vm.fieldData, "type", $$v)
                            },
                            expression: "fieldData.type"
                          }
                        },
                        [
                          _c("vs-select-item", {
                            attrs: { value: "string", text: "string" }
                          }),
                          _vm._v(" "),
                          _c("vs-select-item", {
                            attrs: { value: "number", text: "number" }
                          }),
                          _vm._v(" "),
                          _c("vs-select-item", {
                            attrs: { value: "select", text: "select" }
                          }),
                          _vm._v(" "),
                          _c("vs-select-item", {
                            attrs: {
                              value: "multi-select",
                              text: "multi-select"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "vx-col w-1/2" },
                    [
                      _c(
                        "vs-select",
                        {
                          directives: [
                            {
                              name: "validate",
                              rawName: "v-validate",
                              value: "required",
                              expression: "'required'"
                            }
                          ],
                          staticClass: "w-full",
                          attrs: {
                            name: "service_id",
                            label: "company or talanted"
                          },
                          model: {
                            value: _vm.fieldData.role_id,
                            callback: function($$v) {
                              _vm.$set(_vm.fieldData, "role_id", $$v)
                            },
                            expression: "fieldData.role_id"
                          }
                        },
                        _vm._l(_vm.roles, function(item, index) {
                          return _c("vs-select-item", {
                            key: index,
                            attrs: { value: item.id, text: item.name }
                          })
                        }),
                        1
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "vx-col mt-5 w-1/2" },
                    [
                      _c(
                        "vs-switch",
                        {
                          model: {
                            value: _vm.fieldData.mandatory,
                            callback: function($$v) {
                              _vm.$set(_vm.fieldData, "mandatory", $$v)
                            },
                            expression: "fieldData.mandatory"
                          }
                        },
                        [
                          _c("span", { attrs: { slot: "on" }, slot: "on" }, [
                            _vm._v("mandatory")
                          ]),
                          _vm._v(" "),
                          _c("span", { attrs: { slot: "off" }, slot: "off" }, [
                            _vm._v("optional")
                          ])
                        ]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _vm.fieldData.type == "select" ||
                  _vm.fieldData.type == "multi-select"
                    ? _c(
                        "vx-card",
                        {
                          staticClass:
                            "vx-col w-full sm:w-full sm:w-full lg:w-full xl:w-full flex flex-col overflow-hidden my-5",
                          attrs: { title: _vm.fieldData.type + "  items" }
                        },
                        [
                          [
                            _c("vs-button", {
                              staticClass: "mb-2 float-right",
                              attrs: {
                                type: "gradient",
                                icon: "icon-plus",
                                "icon-pack": "feather",
                                radius: "",
                                color: "primary"
                              },
                              on: {
                                click: function($event) {
                                  return _vm.addItem()
                                }
                              }
                            }),
                            _vm._v(" "),
                            _c(
                              "div",
                              { staticClass: "vx-row w-full mb-2" },
                              _vm._l(_vm.fieldData.items, function(
                                item,
                                index
                              ) {
                                return _c(
                                  "div",
                                  { key: index, staticClass: "vx-col w-full" },
                                  [
                                    _c(
                                      "div",
                                      { staticClass: "vx-row w-full mb-2" },
                                      [
                                        _c("vs-input", {
                                          directives: [
                                            {
                                              name: "validate",
                                              rawName: "v-validate",
                                              value: "required",
                                              expression: "'required'"
                                            }
                                          ],
                                          staticClass: "vx-col w-1/3",
                                          attrs: {
                                            type: "text",
                                            "icon-pack": "feather",
                                            icon: "icon-edit",
                                            "icon-no-border": "",
                                            "label-placeholder": "name"
                                          },
                                          model: {
                                            value: item.name,
                                            callback: function($$v) {
                                              _vm.$set(item, "name", $$v)
                                            },
                                            expression: "item.name"
                                          }
                                        }),
                                        _vm._v(" "),
                                        _c("vs-input", {
                                          directives: [
                                            {
                                              name: "validate",
                                              rawName: "v-validate",
                                              value: "required",
                                              expression: "'required'"
                                            }
                                          ],
                                          staticClass: "vx-col w-1/3",
                                          attrs: {
                                            type: "text",
                                            "icon-pack": "feather",
                                            icon: "icon-edit",
                                            "icon-no-border": "",
                                            "label-placeholder":
                                              "name in arabic"
                                          },
                                          model: {
                                            value: item.name_ar,
                                            callback: function($$v) {
                                              _vm.$set(item, "name_ar", $$v)
                                            },
                                            expression: "item.name_ar"
                                          }
                                        }),
                                        _vm._v(" "),
                                        _c("vs-button", {
                                          staticClass:
                                            "vx-col w-1/3 float-right mt-4",
                                          attrs: {
                                            type: "gradient",
                                            icon: "icon-trash",
                                            "icon-pack": "feather",
                                            radius: "",
                                            color: "danger"
                                          },
                                          on: {
                                            click: function($event) {
                                              return _vm.removeItem(index)
                                            }
                                          }
                                        })
                                      ],
                                      1
                                    )
                                  ]
                                )
                              }),
                              0
                            )
                          ]
                        ],
                        2
                      )
                    : _vm._e()
                ],
                1
              ),
              _vm._v(" "),
              _c("div", { staticClass: "vx-row" }, [
                _c(
                  "div",
                  { staticClass: "vx-col w-full mt-5" },
                  [
                    _c(
                      "vs-button",
                      {
                        staticClass: "mr-3 mb-2",
                        attrs: { color: "primary" },
                        on: {
                          click: function($event) {
                            return _vm.submitData()
                          }
                        }
                      },
                      [_vm._v("Submit")]
                    )
                  ],
                  1
                )
              ])
            ])
          ],
          1
        )
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/field/add.vue":
/*!**********************************************!*\
  !*** ./resources/js/src/views/field/add.vue ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _add_vue_vue_type_template_id_42fee872___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./add.vue?vue&type=template&id=42fee872& */ "./resources/js/src/views/field/add.vue?vue&type=template&id=42fee872&");
/* harmony import */ var _add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./add.vue?vue&type=script&lang=js& */ "./resources/js/src/views/field/add.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _add_vue_vue_type_template_id_42fee872___WEBPACK_IMPORTED_MODULE_0__["render"],
  _add_vue_vue_type_template_id_42fee872___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/field/add.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/field/add.vue?vue&type=script&lang=js&":
/*!***********************************************************************!*\
  !*** ./resources/js/src/views/field/add.vue?vue&type=script&lang=js& ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./add.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/field/add.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/field/add.vue?vue&type=template&id=42fee872&":
/*!*****************************************************************************!*\
  !*** ./resources/js/src/views/field/add.vue?vue&type=template&id=42fee872& ***!
  \*****************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_add_vue_vue_type_template_id_42fee872___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./add.vue?vue&type=template&id=42fee872& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/field/add.vue?vue&type=template&id=42fee872&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_add_vue_vue_type_template_id_42fee872___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_add_vue_vue_type_template_id_42fee872___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);