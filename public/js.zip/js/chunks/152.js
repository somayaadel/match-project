(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[152],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/field/profileFields.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/field/profileFields.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _axios_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../axios.js */ "./resources/js/src/axios.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      fields: [],
      staffData: {
        user: ""
      },
      allStaff: [],
      searchQuery: ""
    };
  },
  watch: {
    application_id: function application_id(val) {
      this.filterFields();
    }
  },
  computed: {
    application_id: function application_id() {
      return this.$store.state.application_id;
    }
  },
  mounted: function mounted() {
    this.getFields();
  },
  methods: {
    getFields: function getFields() {
      var _this = this;

      _axios_js__WEBPACK_IMPORTED_MODULE_0__["default"].get("/api/field").then(function (res) {
        _this.fields = res.data.data;
        _this.allFields = res.data.data;

        _this.filterFields();
      }).catch(function (err) {
        console.log(err);
      });
    },
    showDeleteSuccess: function showDeleteSuccess() {
      this.$vs.notify({
        color: "success",
        title: "User Deleted",
        text: "The selected user was successfully deleted"
      });
    },
    submitData: function submitData() {
      var _this2 = this;

      _axios_js__WEBPACK_IMPORTED_MODULE_0__["default"].put('/api/field', this.fields).then(function (res) {
        _this2.showSuccess('updated successfully');
      }).catch(function (err) {
        console.log(err);
      });
    },
    showSuccess: function showSuccess(msg) {
      this.$vs.notify({
        color: 'success',
        title: 'User Deleted',
        text: msg
      });
    },
    filterFields: function filterFields() {
      var component = this;
      this.fields = JSON.parse(JSON.stringify(this.allFields.filter(function (field) {
        return field.application_id == component.application_id;
      })));
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/field/profileFields.vue?vue&type=template&id=3a7c35d3&":
/*!*********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/field/profileFields.vue?vue&type=template&id=3a7c35d3& ***!
  \*********************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm.fields
    ? _c("div", [
        _c(
          "div",
          { attrs: { "bg-white": "" } },
          [
            _c("div", { staticClass: "vs-row flex" }, [
              _c("div", { staticClass: "w-1/4 mb-6" }, [
                _c(
                  "div",
                  { staticClass: "search-page__search-bar flex items-center" },
                  [
                    _c("vs-input", {
                      staticClass: "w-full input-rounded-full p-5",
                      attrs: {
                        name: "Roles",
                        "icon-no-border": "",
                        placeholder: "Search",
                        icon: "icon-search",
                        "icon-pack": "feather"
                      }
                    })
                  ],
                  1
                )
              ])
            ]),
            _vm._v(" "),
            _c(
              "vx-card",
              [
                _c("div", { staticClass: "vx-row p-5" }, [
                  _c("h3", [_vm._v("Edit Application Profile Fields")])
                ]),
                _vm._v(" "),
                _c(
                  "vx-card",
                  [
                    _c(
                      "vs-table",
                      {
                        attrs: {
                          pagination: "",
                          "max-items": 6,
                          search: "",
                          data: _vm.fields
                        }
                      },
                      [
                        _c(
                          "template",
                          { slot: "thead" },
                          [
                            _c(
                              "vs-th",
                              {
                                staticClass: "tableHead",
                                attrs: { "sort-key": "name" }
                              },
                              [_vm._v("required")]
                            ),
                            _vm._v(" "),
                            _c(
                              "vs-th",
                              {
                                staticClass: "tableHead",
                                attrs: { "sort-key": "name" }
                              },
                              [_vm._v("name")]
                            ),
                            _vm._v(" "),
                            _c(
                              "vs-th",
                              {
                                staticClass: "tableHead",
                                attrs: { "sort-key": "name" }
                              },
                              [_vm._v("arabic name")]
                            ),
                            _vm._v(" "),
                            _c(
                              "vs-th",
                              {
                                staticClass: "tableHead",
                                attrs: { "sort-key": "name" }
                              },
                              [_vm._v("mandatory")]
                            )
                          ],
                          1
                        ),
                        _vm._v(" "),
                        _vm._l(_vm.fields, function(item, index) {
                          return _c(
                            "vs-tr",
                            { key: index, staticClass: "vs-align-center" },
                            [
                              _c(
                                "vs-td",
                                [
                                  _c(
                                    "vx-tooltip",
                                    {
                                      attrs: {
                                        color: "primary",
                                        text:
                                          "select the field to display it in user profile field"
                                      }
                                    },
                                    [
                                      _c("vs-checkbox", {
                                        model: {
                                          value: _vm.fields[index].required,
                                          callback: function($$v) {
                                            _vm.$set(
                                              _vm.fields[index],
                                              "required",
                                              $$v
                                            )
                                          },
                                          expression: "fields[index].required"
                                        }
                                      })
                                    ],
                                    1
                                  )
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _c("vs-td", [
                                _vm._v(
                                  "\n                      " +
                                    _vm._s(_vm.fields[index].name) +
                                    "\n                  "
                                )
                              ]),
                              _vm._v(" "),
                              _c("vs-td", [
                                _vm._v(
                                  "\n                      " +
                                    _vm._s(_vm.fields[index].name_ar) +
                                    "\n                  "
                                )
                              ]),
                              _vm._v(" "),
                              _c("vs-td", [
                                _c(
                                  "div",
                                  { staticClass: "vx-col" },
                                  [
                                    _c(
                                      "vs-switch",
                                      {
                                        model: {
                                          value: _vm.fields[index].mandatory,
                                          callback: function($$v) {
                                            _vm.$set(
                                              _vm.fields[index],
                                              "mandatory",
                                              $$v
                                            )
                                          },
                                          expression: "fields[index].mandatory"
                                        }
                                      },
                                      [
                                        _c(
                                          "span",
                                          { attrs: { slot: "on" }, slot: "on" },
                                          [_vm._v("mandatory")]
                                        ),
                                        _vm._v(" "),
                                        _c(
                                          "span",
                                          {
                                            attrs: { slot: "off" },
                                            slot: "off"
                                          },
                                          [_vm._v("optional")]
                                        )
                                      ]
                                    )
                                  ],
                                  1
                                )
                              ])
                            ],
                            1
                          )
                        })
                      ],
                      2
                    )
                  ],
                  1
                )
              ],
              1
            ),
            _vm._v(" "),
            _c("div", { staticClass: "vx-row" }, [
              _c(
                "div",
                { staticClass: "vx-col w-full mt-5" },
                [
                  _c(
                    "vs-button",
                    {
                      staticClass: "mr-3 mb-2",
                      attrs: { color: "primary" },
                      on: {
                        click: function($event) {
                          return _vm.submitData()
                        }
                      }
                    },
                    [_vm._v("Save")]
                  )
                ],
                1
              )
            ])
          ],
          1
        )
      ])
    : _vm._e()
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/field/profileFields.vue":
/*!********************************************************!*\
  !*** ./resources/js/src/views/field/profileFields.vue ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _profileFields_vue_vue_type_template_id_3a7c35d3___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profileFields.vue?vue&type=template&id=3a7c35d3& */ "./resources/js/src/views/field/profileFields.vue?vue&type=template&id=3a7c35d3&");
/* harmony import */ var _profileFields_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profileFields.vue?vue&type=script&lang=js& */ "./resources/js/src/views/field/profileFields.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _profileFields_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _profileFields_vue_vue_type_template_id_3a7c35d3___WEBPACK_IMPORTED_MODULE_0__["render"],
  _profileFields_vue_vue_type_template_id_3a7c35d3___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/field/profileFields.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/field/profileFields.vue?vue&type=script&lang=js&":
/*!*********************************************************************************!*\
  !*** ./resources/js/src/views/field/profileFields.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_profileFields_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./profileFields.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/field/profileFields.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_profileFields_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/field/profileFields.vue?vue&type=template&id=3a7c35d3&":
/*!***************************************************************************************!*\
  !*** ./resources/js/src/views/field/profileFields.vue?vue&type=template&id=3a7c35d3& ***!
  \***************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_profileFields_vue_vue_type_template_id_3a7c35d3___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./profileFields.vue?vue&type=template&id=3a7c35d3& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/field/profileFields.vue?vue&type=template&id=3a7c35d3&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_profileFields_vue_vue_type_template_id_3a7c35d3___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_profileFields_vue_vue_type_template_id_3a7c35d3___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);