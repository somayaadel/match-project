(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[123],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/card/CardColors.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui-elements/card/CardColors.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      card_bg_img_1: __webpack_require__(/*! @assets/images/pages/card-bg-image-demo-1.jpg */ "./resources/assets/images/pages/card-bg-image-demo-1.jpg"),
      card_bg_img_2: __webpack_require__(/*! @assets/images/pages/card-bg-image-demo-2.jpg */ "./resources/assets/images/pages/card-bg-image-demo-2.jpg")
    };
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/card/CardColors.vue?vue&type=template&id=27297606&":
/*!*****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui-elements/card/CardColors.vue?vue&type=template&id=27297606& ***!
  \*****************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "vx-row" }, [
    _c(
      "div",
      {
        staticClass: "vx-col w-full sm:w-1/2 md:w-1/2 lg:w-1/2 xl:w-1/2 mb-base"
      },
      [
        _c(
          "vx-card",
          {
            attrs: {
              title: "Title Color",
              "title-color": "primary",
              subtitle: "Brownie pastry chocolate pastry chocolate pudding.",
              "code-toggler": ""
            }
          },
          [
            _c("p", { staticClass: "mb-3" }, [
              _vm._v("You can use "),
              _c("code", [_vm._v("title-color")]),
              _vm._v(
                " prop to change color of title of card. This prop supports hex, rgba, rgb and theme colors."
              )
            ]),
            _vm._v(" "),
            _c("p", { staticClass: "mb-3" }, [
              _vm._v(
                "Oat cake powder sesame snaps. Chocolate bar dessert bonbon chocolate bar pudding apple pie muffin chocolate ice cream. I love bear claw I love."
              )
            ]),
            _vm._v(" "),
            _c("template", { slot: "codeContainer" }, [
              _vm._v(
                '\n<vx-card\n    title="Title Color"\n    title-color="primary"\n    subtitle="Brownie pastry chocolate pastry chocolate pudding.">\n    <p class="mb-3">You can use <code>title-color</code> prop to change color of title of card. This prop supports hex, rgba, rgb and theme colors.</p>\n    <p class="mb-3">Oat cake powder sesame snaps. Chocolate bar dessert bonbon chocolate bar pudding apple pie muffin chocolate ice cream. I love bear claw I love.</p>\n</vx-card>\n                '
              )
            ])
          ],
          2
        )
      ],
      1
    ),
    _vm._v(" "),
    _c(
      "div",
      {
        staticClass: "vx-col w-full sm:w-1/2 md:w-1/2 lg:w-1/2 xl:w-1/2 mb-base"
      },
      [
        _c(
          "vx-card",
          {
            attrs: {
              title: "Title Color",
              "title-color": "success",
              subtitle: "Brownie pastry chocolate pastry chocolate pudding.",
              "code-toggler": ""
            }
          },
          [
            _c("p", { staticClass: "mb-3" }, [
              _vm._v("You can use "),
              _c("code", [_vm._v("title-color")]),
              _vm._v(
                " prop to change color of title of card. This prop supports hex, rgba, rgb and theme colors."
              )
            ]),
            _vm._v(" "),
            _c("p", { staticClass: "mb-3" }, [
              _vm._v(
                "Oat cake powder sesame snaps. Chocolate bar dessert bonbon chocolate bar pudding apple pie muffin chocolate ice cream. I love bear claw I love."
              )
            ]),
            _vm._v(" "),
            _c("template", { slot: "codeContainer" }, [
              _vm._v(
                '\n<vx-card\n    title="Title Color"\n    title-color="success"\n    subtitle="Brownie pastry chocolate pastry chocolate pudding.">\n    <p class="mb-3">You can use <code>title-color</code> prop to change color of title of card. This prop supports hex, rgba, rgb and theme colors.</p>\n    <p class="mb-3">Oat cake powder sesame snaps. Chocolate bar dessert bonbon chocolate bar pudding apple pie muffin chocolate ice cream. I love bear claw I love.</p>\n</vx-card>\n                '
              )
            ])
          ],
          2
        )
      ],
      1
    ),
    _vm._v(" "),
    _c(
      "div",
      {
        staticClass: "vx-col w-full sm:w-1/2 md:w-1/2 lg:w-1/2 xl:w-1/2 mb-base"
      },
      [
        _c(
          "vx-card",
          {
            attrs: {
              title: "Subtitle Color",
              "title-color": "primary",
              "subtitle-color": "warning",
              subtitle: "Brownie pastry chocolate pastry chocolate pudding.",
              "code-toggler": ""
            }
          },
          [
            _c("p", { staticClass: "mb-3" }, [
              _vm._v("You can use "),
              _c("code", [_vm._v("subtitle-color")]),
              _vm._v(
                " prop to change color of subtitle of card. This prop supports hex, rgba, rgb and theme colors."
              )
            ]),
            _vm._v(" "),
            _c("template", { slot: "codeContainer" }, [
              _vm._v(
                '\n<vx-card\n    title="Subtitle Color"\n    title-color="primary"\n    subtitle-color="warning"\n    subtitle="Brownie pastry chocolate pastry chocolate pudding.">\n    <p class="mb-3">You can use <code>subtitle-color</code> prop to change color of subtitle of card. This prop supports hex, rgba, rgb and theme colors.</p>\n</vx-card>\n                '
              )
            ])
          ],
          2
        )
      ],
      1
    ),
    _vm._v(" "),
    _c(
      "div",
      {
        staticClass: "vx-col w-full sm:w-1/2 md:w-1/2 lg:w-1/2 xl:w-1/2 mb-base"
      },
      [
        _c(
          "vx-card",
          {
            attrs: {
              title: "Content Color",
              "title-color": "primary",
              "content-color": "warning",
              subtitle: "Brownie pastry chocolate pastry chocolate pudding.",
              "code-toggler": ""
            }
          },
          [
            _c("p", { staticClass: "mb-3" }, [
              _vm._v("You can use "),
              _c("code", [_vm._v("content-color")]),
              _vm._v(
                " prop to change color of title of card. This prop supports hex, rgba, rgb and theme colors."
              )
            ]),
            _vm._v(" "),
            _c("template", { slot: "codeContainer" }, [
              _vm._v(
                '\n<vx-card\n    title="Content Color"\n    title-color="primary"\n    content-color="warning"\n    subtitle="Brownie pastry chocolate pastry chocolate pudding."\n    code-toggler>\n    <p class="mb-3">You can use <code>content-color</code> prop to change color of title of card. This prop supports hex, rgba, rgb and theme colors.</p>\n</vx-card>\n                '
              )
            ])
          ],
          2
        )
      ],
      1
    ),
    _vm._v(" "),
    _c(
      "div",
      {
        staticClass: "vx-col w-full sm:w-1/2 md:w-1/2 lg:w-1/2 xl:w-1/2 mb-base"
      },
      [
        _c(
          "vx-card",
          {
            attrs: {
              title: "Background Color",
              "title-color": "#fff",
              "card-background": "primary",
              "content-color": "#fff",
              "code-toggler": ""
            }
          },
          [
            _c("p", { staticClass: "mb-3" }, [
              _vm._v("You can use "),
              _c("strong", [_vm._v("card-background")]),
              _vm._v(
                " prop to change background color of card. This prop supports hex, rgba, rgb and theme colors."
              )
            ]),
            _vm._v(" "),
            _c("p", { staticClass: "mb-3" }, [
              _vm._v(
                "Oat cake powder sesame snaps. Chocolate bar dessert bonbon chocolate bar pudding apple pie muffin chocolate ice cream. I love bear claw I love."
              )
            ]),
            _vm._v(" "),
            _c("template", { slot: "codeContainer" }, [
              _vm._v(
                '\n<vx-card\n    title="Background Color"\n    title-color="#fff"\n    card-background="primary"\n    content-color="#fff">\n    <p class="mb-3">You can use <strong>card-background</strong> prop to change background color of card. This prop supports hex, rgba, rgb and theme colors.</p>\n    <p class="mb-3">Oat cake powder sesame snaps. Chocolate bar dessert bonbon chocolate bar pudding apple pie muffin chocolate ice cream. I love bear claw I love.</p>\n</vx-card>\n                '
              )
            ])
          ],
          2
        )
      ],
      1
    ),
    _vm._v(" "),
    _c(
      "div",
      {
        staticClass: "vx-col w-full sm:w-1/2 md:w-1/2 lg:w-1/2 xl:w-1/2 mb-base"
      },
      [
        _c(
          "vx-card",
          {
            attrs: {
              title: "Background Color",
              "title-color": "#fff",
              "card-background": "success",
              "content-color": "#fff",
              "code-toggler": ""
            }
          },
          [
            _c("p", { staticClass: "mb-3" }, [
              _vm._v("You can use "),
              _c("strong", [_vm._v("card-background")]),
              _vm._v(
                " prop to change background color of card. This prop supports hex, rgba, rgb and theme colors."
              )
            ]),
            _vm._v(" "),
            _c("p", { staticClass: "mb-3" }, [
              _vm._v(
                "Oat cake powder sesame snaps. Chocolate bar dessert bonbon chocolate bar pudding apple pie muffin chocolate ice cream. I love bear claw I love."
              )
            ]),
            _vm._v(" "),
            _c("template", { slot: "codeContainer" }, [
              _vm._v(
                '\n<vx-card\n    title="Background Color"\n    title-color="#fff"\n    card-background="success"\n    content-color="#fff">\n    <p class="mb-3">You can use <strong>card-background</strong> prop to change background color of card. This prop supports hex, rgba, rgb and theme colors.</p>\n    <p class="mb-3">Oat cake powder sesame snaps. Chocolate bar dessert bonbon chocolate bar pudding apple pie muffin chocolate ice cream. I love bear claw I love.</p>\n</vx-card>\n                '
              )
            ])
          ],
          2
        )
      ],
      1
    ),
    _vm._v(" "),
    _c(
      "div",
      {
        staticClass: "vx-col w-full sm:w-1/2 md:w-1/2 lg:w-1/2 xl:w-1/2 mb-base"
      },
      [
        _c(
          "vx-card",
          {
            attrs: {
              title: "Gradient Background Color",
              "title-color": "#fff",
              "content-color": "#fff",
              "card-background":
                "linear-gradient(120deg, #7f7fd5, #86a8e7, #91eae4)",
              "code-toggler": ""
            }
          },
          [
            _c("p", { staticClass: "mb-3" }, [
              _vm._v("You can use "),
              _c("strong", [_vm._v("card-background")]),
              _vm._v(
                " prop to change background color of card. This prop supports hex, rgba, rgb and theme colors."
              )
            ]),
            _vm._v(" "),
            _c("p", { staticClass: "mb-3" }, [
              _vm._v(
                "Oat cake powder sesame snaps. Chocolate bar dessert bonbon chocolate bar pudding apple pie muffin chocolate ice cream. I love bear claw I love."
              )
            ]),
            _vm._v(" "),
            _c("template", { slot: "codeContainer" }, [
              _vm._v(
                '\n<vx-card\n    title="Gradient Background Color"\n    title-color="#fff"\n    content-color="#fff"\n    card-background="linear-gradient(120deg, #7f7fd5, #86a8e7, #91eae4)">\n    <p class="mb-3">You can use <strong>card-background</strong> prop to change background color of card. This prop supports hex, rgba, rgb and theme colors.</p>\n    <p class="mb-3">Oat cake powder sesame snaps. Chocolate bar dessert bonbon chocolate bar pudding apple pie muffin chocolate ice cream. I love bear claw I love.</p>\n</vx-card>\n                '
              )
            ])
          ],
          2
        )
      ],
      1
    ),
    _vm._v(" "),
    _c(
      "div",
      {
        staticClass: "vx-col w-full sm:w-1/2 md:w-1/2 lg:w-1/2 xl:w-1/2 mb-base"
      },
      [
        _c(
          "vx-card",
          {
            attrs: {
              title: "Gradient Background Color",
              "title-color": "#fff",
              "content-color": "#fff",
              "card-background": "linear-gradient(to right, #56ab2f, #a8e063)",
              "code-toggler": ""
            }
          },
          [
            _c("p", { staticClass: "mb-3" }, [
              _vm._v("You can use "),
              _c("strong", [_vm._v("card-background")]),
              _vm._v(
                " prop to change background color of card. This prop supports hex, rgba, rgb and theme colors."
              )
            ]),
            _vm._v(" "),
            _c("p", { staticClass: "mb-3" }, [
              _vm._v(
                "Oat cake powder sesame snaps. Chocolate bar dessert bonbon chocolate bar pudding apple pie muffin chocolate ice cream. I love bear claw I love."
              )
            ]),
            _vm._v(" "),
            _c("template", { slot: "codeContainer" }, [
              _vm._v(
                '\n<vx-card\n    title="Gradient Background Color"\n    title-color="#fff"\n    content-color="#fff"\n    card-background="linear-gradient(to right, #56ab2f, #a8e063)">\n    <p class="mb-3">You can use <strong>card-background</strong> prop to change background color of card. This prop supports hex, rgba, rgb and theme colors.</p>\n    <p class="mb-3">Oat cake powder sesame snaps. Chocolate bar dessert bonbon chocolate bar pudding apple pie muffin chocolate ice cream. I love bear claw I love.</p>\n</vx-card>\n                '
              )
            ])
          ],
          2
        )
      ],
      1
    ),
    _vm._v(" "),
    _c(
      "div",
      {
        staticClass: "vx-col w-full sm:w-1/2 md:w-1/2 lg:w-1/2 xl:w-1/2 mb-base"
      },
      [
        _c(
          "vx-card",
          {
            staticClass: "card-overlay bg-cover",
            attrs: {
              title: "Gradient Background Image",
              "title-color": "#fff",
              "content-color": "#fff",
              "card-background":
                "linear-gradient(120deg ,rgba(109,213,237,.8), rgba(33,147,176,0.5)), url(" +
                _vm.card_bg_img_1 +
                ")",
              "code-toggler": ""
            }
          },
          [
            _c("p", { staticClass: "mb-3" }, [
              _vm._v("You can use "),
              _c("strong", [_vm._v("card-background")]),
              _vm._v(
                " prop to change background of card. This prop supports hex, rgba, rgb and theme colors."
              )
            ]),
            _vm._v(" "),
            _c("p", { staticClass: "mb-3" }, [
              _vm._v(
                "Oat cake powder sesame snaps. Chocolate bar dessert bonbon chocolate bar pudding apple pie muffin chocolate ice cream. I love bear claw I love."
              )
            ]),
            _vm._v(" "),
            _c("template", { slot: "codeContainer" }, [
              _vm._v(
                '\n<template>\n  <vx-card\n      title="Gradient Background Image"\n      title-color="#fff"\n      content-color="#fff"\n      :card-background="\'linear-gradient(120deg ,rgba(109,213,237,.8), rgba(33,147,176,0.5)), url(\' + card_bg_img_1 + \')\'"\n      code-toggler>\n      <p class="mb-3">You can use <strong>card-background</strong> prop to change background of card. This prop supports hex, rgba, rgb and theme colors.</p>\n      <p class="mb-3">Oat cake powder sesame snaps. Chocolate bar dessert bonbon chocolate bar pudding apple pie muffin chocolate ice cream. I love bear claw I love.</p>\n  </vx-card>\n</template>\n\n<script>\nexport default{\n  data() {\n    return {\n      card_bg_img_1: require(\'@assets/images/pages/card-bg-image-demo-1.jpg\')\n    }\n  }\n}\n</script>\n                '
              )
            ])
          ],
          2
        )
      ],
      1
    ),
    _vm._v(" "),
    _c(
      "div",
      {
        staticClass: "vx-col w-full sm:w-1/2 md:w-1/2 lg:w-1/2 xl:w-1/2 mb-base"
      },
      [
        _c(
          "vx-card",
          {
            staticClass: "card-overlay bg-cover",
            attrs: {
              title: "Gradient Background Image",
              "title-color": "#fff",
              "content-color": "#fff",
              "card-background":
                "linear-gradient(120deg ,rgba(247,97,161,0.5), rgba(140,27,171,.8)), url(" +
                _vm.card_bg_img_2 +
                ")",
              "code-toggler": ""
            }
          },
          [
            _c("p", { staticClass: "mb-3" }, [
              _vm._v("You can use "),
              _c("strong", [_vm._v("card-background")]),
              _vm._v(
                " prop to change background of card. This prop supports hex, rgba, rgb and theme colors."
              )
            ]),
            _vm._v(" "),
            _c("p", { staticClass: "mb-3" }, [
              _vm._v(
                "Oat cake powder sesame snaps. Chocolate bar dessert bonbon chocolate bar pudding apple pie muffin chocolate ice cream. I love bear claw I love."
              )
            ]),
            _vm._v(" "),
            _c("template", { slot: "codeContainer" }, [
              _vm._v(
                '\n<template>\n  <vx-card\n      title="Gradient Background Image"\n      title-color="#fff"\n      content-color="#fff"\n      :card-background="\'linear-gradient(120deg ,rgba(247,97,161,0.5), rgba(140,27,171,.8)), url(\' + card_bg_img_2 + \')\'"\n      code-toggler>\n      <p class="mb-3">You can use <strong>card-background</strong> prop to change background of card. This prop supports hex, rgba, rgb and theme colors.</p>\n      <p class="mb-3">Oat cake powder sesame snaps. Chocolate bar dessert bonbon chocolate bar pudding apple pie muffin chocolate ice cream. I love bear claw I love.</p>\n  </vx-card>\n</template>\n\n<script>\nexport default{\n  data() {\n    return {\n      card_bg_img_2: require(\'@assets/images/pages/card-bg-image-demo-2.jpg\')\n    }\n  }\n}\n</script>\n                '
              )
            ])
          ],
          2
        )
      ],
      1
    )
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/assets/images/pages/card-bg-image-demo-1.jpg":
/*!****************************************************************!*\
  !*** ./resources/assets/images/pages/card-bg-image-demo-1.jpg ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/card-bg-image-demo-1.jpg?36390f4bd33e1ada9e3f09979d7e6f05";

/***/ }),

/***/ "./resources/assets/images/pages/card-bg-image-demo-2.jpg":
/*!****************************************************************!*\
  !*** ./resources/assets/images/pages/card-bg-image-demo-2.jpg ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/card-bg-image-demo-2.jpg?720ceb82fd5df9730db9e0b33ec1c987";

/***/ }),

/***/ "./resources/js/src/views/ui-elements/card/CardColors.vue":
/*!****************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/card/CardColors.vue ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CardColors_vue_vue_type_template_id_27297606___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CardColors.vue?vue&type=template&id=27297606& */ "./resources/js/src/views/ui-elements/card/CardColors.vue?vue&type=template&id=27297606&");
/* harmony import */ var _CardColors_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CardColors.vue?vue&type=script&lang=js& */ "./resources/js/src/views/ui-elements/card/CardColors.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _CardColors_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _CardColors_vue_vue_type_template_id_27297606___WEBPACK_IMPORTED_MODULE_0__["render"],
  _CardColors_vue_vue_type_template_id_27297606___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/ui-elements/card/CardColors.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/ui-elements/card/CardColors.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/card/CardColors.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CardColors_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CardColors.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/card/CardColors.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CardColors_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/ui-elements/card/CardColors.vue?vue&type=template&id=27297606&":
/*!***********************************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/card/CardColors.vue?vue&type=template&id=27297606& ***!
  \***********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CardColors_vue_vue_type_template_id_27297606___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CardColors.vue?vue&type=template&id=27297606& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/card/CardColors.vue?vue&type=template&id=27297606&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CardColors_vue_vue_type_template_id_27297606___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CardColors_vue_vue_type_template_id_27297606___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);