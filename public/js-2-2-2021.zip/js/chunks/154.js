(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[154],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/package/add.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/package/add.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _axios_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../axios.js */ "./resources/js/src/axios.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
 // import CellRendererAdd from "./cell-renderer/CellRendererAdd.vue";

/* harmony default export */ __webpack_exports__["default"] = ({
  name: "imageUpload",
  data: function data() {
    return {
      applications: [],
      features: [],
      fields: [],
      roles: [],
      roleName: "",
      oldFields: [],
      package_data: {
        name: "",
        price: "",
        application_id: "",
        AllFeature: [],
        fields: []
      },
      searchQuery: ""
    };
  },
  mounted: function mounted() {},
  created: function created() {
    this.getCreateData();
  },
  computed: {
    application_id: function application_id() {
      return this.$store.state.application_id;
    }
  },
  methods: {
    getCreateData: function getCreateData() {
      var _this = this;

      _axios_js__WEBPACK_IMPORTED_MODULE_0__["default"].get('/api/package/create?application_id=' + this.application_id).then(function (res) {
        _this.features = res.data.features;
        _this.fields = res.data.fields;
        _this.roles = res.data.roles;
        _this.oldFields = JSON.parse(JSON.stringify(res.data.fields));
      });
    },
    addSubcategory: function addSubcategory() {
      this.package_data.AllFeature.push({});
    },
    removeSubcategory: function removeSubcategory(index) {
      this.package_data.AllFeature.splice(index, 1);
    },
    getFeatures: function getFeatures() {
      var _this2 = this;

      _axios_js__WEBPACK_IMPORTED_MODULE_0__["default"].get("/api/feature").then(function (res) {
        _this2.features = res.data.data;
      }).catch(function (err) {
        console.log(err);
      });
    },
    getApplication: function getApplication() {
      var _this3 = this;

      _axios_js__WEBPACK_IMPORTED_MODULE_0__["default"].get("/api/application").then(function (res) {
        _this3.applications = res.data.data;
      }).catch(function (err) {
        console.log(err);
      });
    },
    submitData: function submitData() {
      this.packageLogo = this.$refs.ufile.filesx[0];

      if (!this.$refs.ufile.filesx[0]) {
        this.sendPackagePostRequest();
        return;
      }

      var component = this;
      var reader = new FileReader();
      reader.readAsDataURL(this.packageLogo);

      reader.onload = function () {
        component.packageLogo = reader.result;
        component.package_data.logoFile = reader.result;
        component.sendPackagePostRequest();
      };
    },
    sendPackagePostRequest: function sendPackagePostRequest() {
      var _this4 = this;

      this.$validator.validateAll().then(function (res) {
        _this4.package_data.features = _this4.package_data.AllFeature;
        _this4.package_data.fields = _this4.fields;
        _this4.package_data.application_id = _this4.application_id;
        _this4.package_data.fields = [];

        _this4.fields.forEach(function (element, index) {
          if (_this4.fields[index].required && !_this4.oldFields[index].required) {
            _this4.package_data.fields.push({
              'field_id': _this4.fields[index].id
            });
          }
        });

        _axios_js__WEBPACK_IMPORTED_MODULE_0__["default"].post("/api/package", _this4.package_data).then(function (res) {
          _this4.showSuccess("package is created successfuly");

          _this4.$router.push({
            name: "packageList"
          });
        }).catch(function (err) {
          var errors = err.response.data.errors;
          Object.keys(errors).forEach(function (key) {
            _this4.showError(errors[key]);
          });
        });
      });
    },
    roleChanged: function roleChanged() {
      var _this5 = this;

      this.roles.forEach(function (role) {
        if (role.id == _this5.package_data.role_id) _this5.roleName = role.name;
      });
    },
    showSuccess: function showSuccess(msg) {
      this.$vs.notify({
        color: "success",
        title: "package status",
        text: msg,
        position: "top-right"
      });
    },
    showError: function showError(msg) {
      this.$vs.notify({
        color: "danger",
        title: "Error",
        text: msg,
        position: "top-center"
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/package/add.vue?vue&type=template&id=4afe343e&":
/*!*************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/package/add.vue?vue&type=template&id=4afe343e& ***!
  \*************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "container" }, [
    _vm._m(0),
    _vm._v(" "),
    _vm._m(1),
    _vm._v(" "),
    _c("div", { staticClass: "vx-row mt-5" }, [
      _c(
        "div",
        {
          staticClass:
            "vx-col w-full md:w-full sm:w-full lg:w-full xl:w-full flex flex-col lg:mb-0 md:mb-base sm:mb-0 mb-base mt-4"
        },
        [
          _c(
            "vx-card",
            { attrs: { title: "    " } },
            [
              _c("div", { staticClass: "vx-row mb-2" }, [
                _c(
                  "div",
                  { staticClass: "vx-col w-full" },
                  [
                    _c("vs-input", {
                      directives: [
                        {
                          name: "validate",
                          rawName: "v-validate",
                          value: "required",
                          expression: "'required'"
                        }
                      ],
                      staticClass: "w-full",
                      attrs: {
                        type: "text",
                        "icon-pack": "feather",
                        icon: "icon-user",
                        "icon-no-border": "",
                        "label-placeholder": " Name"
                      },
                      model: {
                        value: _vm.package_data.name,
                        callback: function($$v) {
                          _vm.$set(_vm.package_data, "name", $$v)
                        },
                        expression: "package_data.name"
                      }
                    })
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "vx-col w-full" },
                  [
                    _c("vs-input", {
                      directives: [
                        {
                          name: "validate",
                          rawName: "v-validate",
                          value: "required",
                          expression: "'required'"
                        }
                      ],
                      staticClass: "w-full",
                      attrs: {
                        type: "text",
                        "icon-pack": "feather",
                        icon: "icon-user",
                        "icon-no-border": "",
                        "label-placeholder": "Name in arabic"
                      },
                      model: {
                        value: _vm.package_data.name_ar,
                        callback: function($$v) {
                          _vm.$set(_vm.package_data, "name_ar", $$v)
                        },
                        expression: "package_data.name_ar"
                      }
                    })
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "vx-col w-full" },
                  [
                    _c("vs-input", {
                      directives: [
                        {
                          name: "validate",
                          rawName: "v-validate",
                          value: "required",
                          expression: "'required'"
                        }
                      ],
                      staticClass: "w-full",
                      attrs: {
                        type: "number",
                        "icon-pack": "feather",
                        icon: "icon-user",
                        "icon-no-border": "",
                        "label-placeholder": " price"
                      },
                      model: {
                        value: _vm.package_data.price,
                        callback: function($$v) {
                          _vm.$set(_vm.package_data, "price", $$v)
                        },
                        expression: "package_data.price"
                      }
                    })
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "vx-col w-full" },
                  [
                    _c("vs-input", {
                      directives: [
                        {
                          name: "validate",
                          rawName: "v-validate",
                          value: "required",
                          expression: "'required'"
                        }
                      ],
                      staticClass: "w-full",
                      attrs: {
                        type: "number",
                        "icon-pack": "feather",
                        icon: "icon-user",
                        "icon-no-border": "",
                        "label-placeholder": "duration in days"
                      },
                      model: {
                        value: _vm.package_data.duration,
                        callback: function($$v) {
                          _vm.$set(_vm.package_data, "duration", $$v)
                        },
                        expression: "package_data.duration"
                      }
                    })
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "vx-col w-full" },
                  [
                    _c(
                      "vs-select",
                      {
                        directives: [
                          {
                            name: "validate",
                            rawName: "v-validate",
                            value: "required",
                            expression: "'required'"
                          }
                        ],
                        staticClass: "vx-col w-1/3 selectExample",
                        attrs: {
                          label: "roles",
                          name: "role",
                          "label-placeholder": " role"
                        },
                        on: {
                          input: function($event) {
                            return _vm.roleChanged()
                          }
                        },
                        model: {
                          value: _vm.package_data.role_id,
                          callback: function($$v) {
                            _vm.$set(_vm.package_data, "role_id", $$v)
                          },
                          expression: "package_data.role_id"
                        }
                      },
                      _vm._l(_vm.roles, function(item, index) {
                        return _c("vs-select-item", {
                          key: index,
                          attrs: { value: item.id, text: item.name }
                        })
                      }),
                      1
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c("div", { staticClass: "vx-row mb-6" }, [
                  _c(
                    "div",
                    { staticClass: "vx-col md:w-100 w-full mt-5" },
                    [
                      _c("vs-upload", {
                        ref: "ufile",
                        attrs: {
                          limit: "1",
                          automatic: "",
                          text: "Add Package picture",
                          fileName: "CODE",
                          action: ""
                        }
                      })
                    ],
                    1
                  )
                ])
              ]),
              _vm._v(" "),
              _c(
                "vx-card",
                {
                  staticClass:
                    "vx-col w-full sm:w-full sm:w-full lg:w-full xl:w-full flex flex-col overflow-hidden my-5",
                  attrs: { title: "Add More Feature" }
                },
                [
                  [
                    _c("vs-button", {
                      directives: [
                        {
                          name: "validate",
                          rawName: "v-validate",
                          value: "required",
                          expression: "'required'"
                        }
                      ],
                      staticClass: "mb-2 float-right",
                      attrs: {
                        type: "gradient",
                        icon: "icon-plus",
                        "icon-pack": "feather",
                        radius: "",
                        color: "primary"
                      },
                      on: {
                        click: function($event) {
                          return _vm.addSubcategory()
                        }
                      }
                    }),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "vx-row w-full mb-2" },
                      _vm._l(_vm.package_data.AllFeature, function(
                        item,
                        index
                      ) {
                        return _c(
                          "div",
                          { key: index, staticClass: "vx-col w-full" },
                          [
                            _c(
                              "div",
                              { staticClass: "vx-row w-full mb-2" },
                              [
                                _c(
                                  "vs-select",
                                  {
                                    directives: [
                                      {
                                        name: "validate",
                                        rawName: "v-validate",
                                        value: "required",
                                        expression: "'required'"
                                      }
                                    ],
                                    staticClass: "vx-col w-1/3 selectExample",
                                    attrs: {
                                      label: "features",
                                      name: "featureName",
                                      "label-placeholder": " featureName"
                                    },
                                    model: {
                                      value: item.feature_id,
                                      callback: function($$v) {
                                        _vm.$set(item, "feature_id", $$v)
                                      },
                                      expression: "item.feature_id"
                                    }
                                  },
                                  _vm._l(_vm.features, function(item, index) {
                                    return _c("vs-select-item", {
                                      key: index,
                                      attrs: { value: item.id, text: item.name }
                                    })
                                  }),
                                  1
                                ),
                                _vm._v(" "),
                                _c("vs-input", {
                                  directives: [
                                    {
                                      name: "validate",
                                      rawName: "v-validate",
                                      value: "required",
                                      expression: "'required'"
                                    }
                                  ],
                                  staticClass: "vx-col w-1/3",
                                  attrs: {
                                    type: "number",
                                    "icon-pack": "feather",
                                    icon: "icon-edit",
                                    "icon-no-border": "",
                                    "label-placeholder": "limitation"
                                  },
                                  model: {
                                    value: item.limitation,
                                    callback: function($$v) {
                                      _vm.$set(item, "limitation", $$v)
                                    },
                                    expression: "item.limitation"
                                  }
                                }),
                                _vm._v(" "),
                                _c("vs-button", {
                                  staticClass: "vx-col w-1/3 float-right mt-4",
                                  attrs: {
                                    type: "gradient",
                                    icon: "icon-trash",
                                    "icon-pack": "feather",
                                    radius: "",
                                    color: "danger"
                                  },
                                  on: {
                                    click: function($event) {
                                      return _vm.removeSubcategory(index)
                                    }
                                  }
                                })
                              ],
                              1
                            )
                          ]
                        )
                      }),
                      0
                    )
                  ]
                ],
                2
              ),
              _vm._v(" "),
              _vm.roleName == "talanted"
                ? _c(
                    "vx-card",
                    {
                      staticClass:
                        "vx-col w-full sm:w-full sm:w-full lg:w-full xl:w-full flex flex-col overflow-hidden my-5",
                      attrs: { title: "profile fields" }
                    },
                    [
                      _c(
                        "vx-card",
                        _vm._l(_vm.fields, function(item, index) {
                          return _c(
                            "vs-checkbox",
                            {
                              key: index,
                              attrs: {
                                color: "success",
                                disabled: _vm.oldFields[index].required == "1"
                              },
                              model: {
                                value: _vm.fields[index].required,
                                callback: function($$v) {
                                  _vm.$set(_vm.fields[index], "required", $$v)
                                },
                                expression: "fields[index].required"
                              }
                            },
                            [_vm._v(_vm._s(item.name))]
                          )
                        }),
                        1
                      )
                    ],
                    1
                  )
                : _vm._e(),
              _vm._v(" "),
              _c("div", { staticClass: "vx-row" }, [
                _c(
                  "div",
                  { staticClass: "vx-col w-full" },
                  [
                    _c(
                      "vs-button",
                      {
                        staticClass: "mr-3 mb-2",
                        attrs: { color: "danger" },
                        on: {
                          click: function($event) {
                            return _vm.submitData()
                          }
                        }
                      },
                      [_vm._v("Submit")]
                    )
                  ],
                  1
                )
              ])
            ],
            1
          )
        ],
        1
      )
    ])
  ])
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "vx-row" }, [
      _c("div", { staticClass: "vx-col w-1/4" })
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "row px-3 w-1/2" }, [
      _c("h1", { staticClass: "my-3 text-title-grey" }, [
        _vm._v("Add New Package")
      ])
    ])
  }
]
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/package/add.vue":
/*!************************************************!*\
  !*** ./resources/js/src/views/package/add.vue ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _add_vue_vue_type_template_id_4afe343e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./add.vue?vue&type=template&id=4afe343e& */ "./resources/js/src/views/package/add.vue?vue&type=template&id=4afe343e&");
/* harmony import */ var _add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./add.vue?vue&type=script&lang=js& */ "./resources/js/src/views/package/add.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _add_vue_vue_type_template_id_4afe343e___WEBPACK_IMPORTED_MODULE_0__["render"],
  _add_vue_vue_type_template_id_4afe343e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/package/add.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/package/add.vue?vue&type=script&lang=js&":
/*!*************************************************************************!*\
  !*** ./resources/js/src/views/package/add.vue?vue&type=script&lang=js& ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./add.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/package/add.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/package/add.vue?vue&type=template&id=4afe343e&":
/*!*******************************************************************************!*\
  !*** ./resources/js/src/views/package/add.vue?vue&type=template&id=4afe343e& ***!
  \*******************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_add_vue_vue_type_template_id_4afe343e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./add.vue?vue&type=template&id=4afe343e& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/package/add.vue?vue&type=template&id=4afe343e&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_add_vue_vue_type_template_id_4afe343e___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_add_vue_vue_type_template_id_4afe343e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);