(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[133],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/companyDashboard.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/companyDashboard.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _axios_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../axios.js */ "./resources/js/src/axios.js");
/* harmony import */ var ag_grid_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ag-grid-vue */ "./node_modules/ag-grid-vue/main.js");
/* harmony import */ var ag_grid_vue__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(ag_grid_vue__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _sass_vuexy_extraComponents_agGridStyleOverride_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @sass/vuexy/extraComponents/agGridStyleOverride.scss */ "./resources/sass/vuexy/extraComponents/agGridStyleOverride.scss");
/* harmony import */ var _sass_vuexy_extraComponents_agGridStyleOverride_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_sass_vuexy_extraComponents_agGridStyleOverride_scss__WEBPACK_IMPORTED_MODULE_2__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    AgGridVue: ag_grid_vue__WEBPACK_IMPORTED_MODULE_1__["AgGridVue"]
  },
  data: function data() {
    return {
      filter: {},
      ageRange: [10, 100],
      result: [],
      cities: [],
      maxPageNumbers: 7,
      totalPages: 1,
      pageSize: 15,
      last_page: 1,
      currentPage: 1,
      gridApi: {},
      gridOptions: {},
      defaultColDef: {
        editable: true,
        sortable: true,
        resizable: true,
        suppressMenu: true
      },
      columnDefs: [{
        headerName: "Name",
        field: "name"
      }, {
        headerName: "Name in Arabic",
        field: "name_ar"
      }, {
        headerName: "Gender",
        valueGetter: this.getGender
      }, {
        headerName: "Address",
        field: "user_data.address"
      }, {
        headerName: "Birth Date",
        field: "user_data.birth_date"
      }]
    };
  },
  watch: {
    currentPage: function currentPage(val) {
      this.search();
    }
  },
  mounted: function mounted() {
    this.getCountryData();
  },
  computed: {
    application_id: function application_id() {
      return this.$store.state.application_id;
    }
  },
  methods: {
    reset: function reset() {
      this.filter = {};
    },
    getCountryData: function getCountryData() {
      var _this = this;

      _axios_js__WEBPACK_IMPORTED_MODULE_0__["default"].get('/api/city/').then(function (res) {
        _this.cities = res.data.data;
      }).catch(function (err) {});
    },
    processData: function processData() {
      this.filter.__min_age = this.ageRange[0];
      this.filter.__max_age = this.ageRange[1];
    },
    search: function search() {
      var _this2 = this;

      this.processData();
      _axios_js__WEBPACK_IMPORTED_MODULE_0__["default"].post('/api/talanted_search?page=' + this.currentPage, this.filter).then(function (res) {
        _this2.result = Object.keys(res.data.data.data).map(function (key) {
          return res.data.data.data[key];
        });
        _this2.totalRecords = res.data.data.total;
        _this2.pageSize = res.data.data.per_page;
        _this2.last_page = res.data.data.last_page;
      });
    },
    getGender: function getGender(params) {
      return params.data.user_data.gender ? 'female' : 'male';
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/companyDashboard.vue?vue&type=template&id=3cd46421&scoped=true&":
/*!******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/companyDashboard.vue?vue&type=template&id=3cd46421&scoped=true& ***!
  \******************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "containe" },
    [
      _c("div", { staticClass: "vx-row" }, [
        _c(
          "div",
          { staticClass: "vx-col " },
          [
            _c("vs-input", {
              attrs: { "label-placeholder": " name" },
              model: {
                value: _vm.filter.__contain_name,
                callback: function($$v) {
                  _vm.$set(_vm.filter, "__contain_name", $$v)
                },
                expression: "filter.__contain_name"
              }
            })
          ],
          1
        ),
        _vm._v(" "),
        _c(
          "div",
          { staticClass: "vx-col " },
          [
            _c("vs-input", {
              attrs: { "label-placeholder": " field5" },
              model: {
                value: _vm.filter.__contain_field5,
                callback: function($$v) {
                  _vm.$set(_vm.filter, "__contain_field5", $$v)
                },
                expression: "filter.__contain_field5"
              }
            })
          ],
          1
        ),
        _vm._v(" "),
        _c(
          "div",
          { staticClass: "vx-col " },
          [
            _c(
              "vs-select",
              {
                attrs: { label: "gender" },
                model: {
                  value: _vm.filter.__equal_gender,
                  callback: function($$v) {
                    _vm.$set(_vm.filter, "__equal_gender", $$v)
                  },
                  expression: "filter.__equal_gender"
                }
              },
              [
                _c("vs-select-item", { attrs: { text: "male", value: "0" } }),
                _vm._v(" "),
                _c("vs-select-item", { attrs: { text: "female", value: "1" } })
              ],
              1
            )
          ],
          1
        ),
        _vm._v(" "),
        _c(
          "div",
          { staticClass: "vx-col " },
          [
            _c("h6", [_vm._v("age : ")]),
            _vm._v(" "),
            _c("vs-slider", {
              model: {
                value: _vm.ageRange,
                callback: function($$v) {
                  _vm.ageRange = $$v
                },
                expression: "ageRange"
              }
            })
          ],
          1
        ),
        _vm._v(" "),
        _c(
          "div",
          { staticClass: "vx-col " },
          [
            _c(
              "vs-select",
              {
                attrs: { name: "city", label: "city" },
                model: {
                  value: _vm.filter.__equal_city_id,
                  callback: function($$v) {
                    _vm.$set(_vm.filter, "__equal_city_id", $$v)
                  },
                  expression: "filter.__equal_city_id"
                }
              },
              _vm._l(_vm.cities, function(item, index) {
                return _c("vs-select-item", {
                  key: index,
                  attrs: { value: item.id, text: item.name }
                })
              }),
              1
            )
          ],
          1
        ),
        _vm._v(" "),
        _c(
          "div",
          { staticClass: "vx-col " },
          [
            _c(
              "vs-button",
              {
                on: {
                  click: function($event) {
                    return _vm.search()
                  }
                }
              },
              [_vm._v("\n          search\n        ")]
            ),
            _vm._v(" "),
            _c(
              "vs-button",
              {
                on: {
                  click: function($event) {
                    return _vm.reset()
                  }
                }
              },
              [_vm._v("\n          reset\n        ")]
            )
          ],
          1
        )
      ]),
      _vm._v(" "),
      _c("ag-grid-vue", {
        ref: "agGridTable",
        staticClass: "ag-theme-material w-100 my-4 ag-grid-table",
        attrs: {
          gridOptions: _vm.gridOptions,
          columnDefs: _vm.columnDefs,
          defaultColDef: _vm.defaultColDef,
          rowData: _vm.result,
          rowSelection: "multiple",
          colResizeDefault: "shift",
          animateRows: true,
          floatingFilter: true,
          enableRtl: _vm.$vs.rtl
        }
      }),
      _vm._v(" "),
      _c("vs-pagination", {
        attrs: { total: _vm.last_page, max: _vm.maxPageNumbers },
        model: {
          value: _vm.currentPage,
          callback: function($$v) {
            _vm.currentPage = $$v
          },
          expression: "currentPage"
        }
      })
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/companyDashboard.vue":
/*!*****************************************************!*\
  !*** ./resources/js/src/views/companyDashboard.vue ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _companyDashboard_vue_vue_type_template_id_3cd46421_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./companyDashboard.vue?vue&type=template&id=3cd46421&scoped=true& */ "./resources/js/src/views/companyDashboard.vue?vue&type=template&id=3cd46421&scoped=true&");
/* harmony import */ var _companyDashboard_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./companyDashboard.vue?vue&type=script&lang=js& */ "./resources/js/src/views/companyDashboard.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _companyDashboard_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _companyDashboard_vue_vue_type_template_id_3cd46421_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _companyDashboard_vue_vue_type_template_id_3cd46421_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "3cd46421",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/companyDashboard.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/companyDashboard.vue?vue&type=script&lang=js&":
/*!******************************************************************************!*\
  !*** ./resources/js/src/views/companyDashboard.vue?vue&type=script&lang=js& ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_companyDashboard_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./companyDashboard.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/companyDashboard.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_companyDashboard_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/companyDashboard.vue?vue&type=template&id=3cd46421&scoped=true&":
/*!************************************************************************************************!*\
  !*** ./resources/js/src/views/companyDashboard.vue?vue&type=template&id=3cd46421&scoped=true& ***!
  \************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_companyDashboard_vue_vue_type_template_id_3cd46421_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./companyDashboard.vue?vue&type=template&id=3cd46421&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/companyDashboard.vue?vue&type=template&id=3cd46421&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_companyDashboard_vue_vue_type_template_id_3cd46421_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_companyDashboard_vue_vue_type_template_id_3cd46421_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);