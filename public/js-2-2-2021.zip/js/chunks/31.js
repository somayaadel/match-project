(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[31],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/Sidebar.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/sidebar/Sidebar.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SidebarDefault_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SidebarDefault.vue */ "./resources/js/src/views/components/vuesax/sidebar/SidebarDefault.vue");
/* harmony import */ var _SidebarParent_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SidebarParent.vue */ "./resources/js/src/views/components/vuesax/sidebar/SidebarParent.vue");
/* harmony import */ var _SidebarStatic_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SidebarStatic.vue */ "./resources/js/src/views/components/vuesax/sidebar/SidebarStatic.vue");
/* harmony import */ var _SidebarGroupCollapsed_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./SidebarGroupCollapsed.vue */ "./resources/js/src/views/components/vuesax/sidebar/SidebarGroupCollapsed.vue");
/* harmony import */ var _SidebarRight_vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./SidebarRight.vue */ "./resources/js/src/views/components/vuesax/sidebar/SidebarRight.vue");
/* harmony import */ var _SidebarReduceExpand_vue__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./SidebarReduceExpand.vue */ "./resources/js/src/views/components/vuesax/sidebar/SidebarReduceExpand.vue");
/* harmony import */ var _SidebarCustom_vue__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./SidebarCustom.vue */ "./resources/js/src/views/components/vuesax/sidebar/SidebarCustom.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//







/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    SidebarDefault: _SidebarDefault_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    SidebarParent: _SidebarParent_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    SidebarStatic: _SidebarStatic_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    SidebarGroupCollapsed: _SidebarGroupCollapsed_vue__WEBPACK_IMPORTED_MODULE_3__["default"],
    SidebarRight: _SidebarRight_vue__WEBPACK_IMPORTED_MODULE_4__["default"],
    SidebarReduceExpand: _SidebarReduceExpand_vue__WEBPACK_IMPORTED_MODULE_5__["default"],
    SidebarCustom: _SidebarCustom_vue__WEBPACK_IMPORTED_MODULE_6__["default"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarDefault.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/sidebar/SidebarDefault.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      active: false
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarGroupCollapsed.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/sidebar/SidebarGroupCollapsed.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      active: false
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarParent.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/sidebar/SidebarParent.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      active: false
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarReduceExpand.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/sidebar/SidebarReduceExpand.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      active: false,
      notExpand: false,
      reduce: true
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarRight.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/sidebar/SidebarRight.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      active: false
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarStatic.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/sidebar/SidebarStatic.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      active: false
    };
  }
});

/***/ }),

/***/ "./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/Sidebar.vue?vue&type=style&index=0&lang=scss&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--8-2!./node_modules/sass-loader/dist/cjs.js??ref--8-3!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/sidebar/Sidebar.vue?vue&type=style&index=0&lang=scss& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "/*=========================================================================================\n    File Name: sidebar.scss\n    Description: Sidebar component style\n    ----------------------------------------------------------------------------------------\n    Item Name: Vuexy - Vuejs, HTML & Laravel Admin Dashboard Template\n      Author: Pixinvent\n    Author URL: http://www.themeforest.net/user/pixinvent\n==========================================================================================*/\n\n/*=========================================================================================\n    File Name: _variables.scss\n    Description: partial- SCSS varibales\n    ----------------------------------------------------------------------------------------\n    Item Name: Vuexy - Vuejs, HTML & Laravel Admin Dashboard Template\n      Author: Pixinvent\n    Author URL: http://www.themeforest.net/user/pixinvent\n==========================================================================================*/\n\n/*========================================================\n        SPACING\n=========================================================*/\n\n/*========================================================\n        COLORS\n=========================================================*/\n\n/*========================================================\n        TYPOGRAPHY\n=========================================================*/\n\n/*========================================================\n        TYPOGRAPHY\n=========================================================*/\n\n/*========================================================\n        DARK THEME\n=========================================================*/\n:root {\n  --vs-primary: 48, 105, 96 ;\n}\n.vs-content-sidebar.sidebarpage .vs-sidebar .vs-sidebar--header .header-sidebar {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  flex-direction: column;\n  width: 100%;\n}\n.vs-content-sidebar.sidebarpage .vs-sidebar .vs-sidebar--header .header-sidebar h4 {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  width: 100%;\n}\n[dir=ltr] .vs-content-sidebar.sidebarpage .vs-sidebar .vs-sidebar--header .header-sidebar h4 > button {\n  margin-left: 10px;\n}\n[dir=rtl] .vs-content-sidebar.sidebarpage .vs-sidebar .vs-sidebar--header .header-sidebar h4 > button {\n  margin-right: 10px;\n}\n.vs-content-sidebar.sidebarpage .vs-sidebar .vs-sidebar--footer .footer-sidebar {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n[dir] .vs-content-sidebar.sidebarpage .vs-sidebar .vs-sidebar--footer .footer-sidebar > button {\n  border: 0px solid rgba(0, 0, 0, 0) !important;\n  border-radius: 0px !important;\n}\n[dir=ltr] .vs-content-sidebar.sidebarpage .vs-sidebar .vs-sidebar--footer .footer-sidebar > button {\n  border-left: 1px solid rgba(0, 0, 0, 0.07) !important;\n}\n[dir=rtl] .vs-content-sidebar.sidebarpage .vs-sidebar .vs-sidebar--footer .footer-sidebar > button {\n  border-right: 1px solid rgba(0, 0, 0, 0.07) !important;\n}\n.vs-content-sidebar.sidebarpage .vs-sidebar .vs-sidebar--item i.material-icons {\n  font-size: 1.2rem;\n}\n.vs-content-sidebar.sidebarpage.sidebar-demo-parent .vs-sidebar {\n  z-index: 10000 !important;\n}\n.vs-content-sidebar.sidebarpage .vs-sidebar--background {\n  z-index: 52000;\n}\n[dir] .theme-dark .vs-content-sidebar.sidebarpage.bordered-sidebar .vs-sidebar {\n  border: 1px solid #414561;\n}", ""]);

// exports


/***/ }),

/***/ "./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarDefault.vue?vue&type=style&index=0&lang=scss&":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--8-2!./node_modules/sass-loader/dist/cjs.js??ref--8-3!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/sidebar/SidebarDefault.vue?vue&type=style&index=0&lang=scss& ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".sidebarpage .vs-sidebar {\n  z-index: 52000;\n}", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/Sidebar.vue?vue&type=style&index=0&lang=scss&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--8-2!./node_modules/sass-loader/dist/cjs.js??ref--8-3!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/sidebar/Sidebar.vue?vue&type=style&index=0&lang=scss& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../../../node_modules/css-loader!../../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../node_modules/postcss-loader/src??ref--8-2!../../../../../../../node_modules/sass-loader/dist/cjs.js??ref--8-3!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Sidebar.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/Sidebar.vue?vue&type=style&index=0&lang=scss&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarDefault.vue?vue&type=style&index=0&lang=scss&":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--8-2!./node_modules/sass-loader/dist/cjs.js??ref--8-3!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/sidebar/SidebarDefault.vue?vue&type=style&index=0&lang=scss& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../../../node_modules/css-loader!../../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../node_modules/postcss-loader/src??ref--8-2!../../../../../../../node_modules/sass-loader/dist/cjs.js??ref--8-3!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SidebarDefault.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarDefault.vue?vue&type=style&index=0&lang=scss&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/Sidebar.vue?vue&type=template&id=a92523c6&":
/*!***********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/sidebar/Sidebar.vue?vue&type=template&id=a92523c6& ***!
  \***********************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { attrs: { id: "sidebar-demo" } },
    [
      _c("sidebar-default"),
      _vm._v(" "),
      _c("sidebar-parent"),
      _vm._v(" "),
      _c("sidebar-static"),
      _vm._v(" "),
      _c("sidebar-group-collapsed"),
      _vm._v(" "),
      _c("sidebar-right"),
      _vm._v(" "),
      _c("sidebar-reduce-expand"),
      _vm._v(" "),
      _c("sidebar-custom")
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarCustom.vue?vue&type=template&id=14353d6e&":
/*!*****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/sidebar/SidebarCustom.vue?vue&type=template&id=14353d6e& ***!
  \*****************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Custom Sidebar", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v(
          "With custom sidebar you can create sidebar items and groups using "
        ),
        _c("strong", [_vm._v(" list of object")]),
        _vm._v(".")
      ]),
      _vm._v(" "),
      _c("p", [
        _vm._v(
          "You can also use feather icons in sidebar group and sidebar items using icon property. Check out all feather icons "
        ),
        _c(
          "a",
          {
            attrs: {
              href: "https://vue-feather-icons.netlify.com/",
              target: "_blank",
              rel: "nofollow"
            }
          },
          [_vm._v("here")]
        )
      ]),
      _vm._v(" "),
      _c("p", { staticClass: "mt-3" }, [
        _vm._v(
          "Main sidebar on left side is demo of Custom Sidebar. You can check full code by clicking on code-toggler icon of this card."
        )
      ]),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n  <v-nav-menu\n    :sidebarItems="sidebarItems"\n    title="Custom"\n    :logo="navMenuLogo">\n</template>\n\n<script>\nimport VNavMenu from "@/layouts/components/vertical-nav-menu/VerticalNavMenu.vue";\n\nexport default {\n  data: () => ({\n    showSidebar: false,\n    navMenuLogo: require(\'@assets/images/logo/logo.png\'),\n    sidebarItems: [\n      {\n        url: "/",\n        name: "Dashboard",\n        slug: "dashboardAnalytics",\n        icon: "HomeIcon",\n        i18n: "Dashboard",\n      },\n      {\n        url: "/ui-elements/colors",\n        name: "Colors",\n        slug: "colors",\n        icon: "DropletIcon",\n        i18n: "Colors",\n      },\n      {\n        header: "Extensions",\n        i18n: "Extensions",\n      },\n      {\n        url: \'/extensions/select\',\n        name: "Select",\n        icon: "PocketIcon",\n        slug: "extraComponentSelect",\n        i18n: "Select",\n      },\n      {\n        url: \'/extensions/quill-editor\',\n        name: "Quill Editor",\n        icon: "EditIcon",\n        slug: "extraComponentQuillEditor",\n        i18n: "QuillEditor",\n      },\n      {\n        url: \'/extensions/drag-and-drop\',\n        name: "Drag & Drop",\n        icon: "DropletIcon",\n        slug: "extraComponentDragAndDrop",\n        i18n: "DragAndDrop",\n      },\n      {\n        url: \'/extensions/datepicker\',\n        name: "Datepicker",\n        icon: "CalendarIcon",\n        slug: "extraComponentDatepicker",\n        i18n: "Datepicker",\n      },\n    ]\n  }),\n  components: {\n    VNavMenu\n  }\n}\n</script>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarDefault.vue?vue&type=template&id=760b45d8&":
/*!******************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/sidebar/SidebarDefault.vue?vue&type=template&id=760b45d8& ***!
  \******************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Default", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v(
          "One of the most common features is to have the hidden sidebar to show it when the user presses a button or makes an action, to add a sidebar we have the component vs-sidebar"
        )
      ]),
      _vm._v(" "),
      _c(
        "vs-alert",
        {
          staticClass: "my-5",
          attrs: { color: "primary", icon: "new_releases", active: "true" }
        },
        [
          _c("p", [
            _vm._v("To add an internal link using "),
            _c(
              "a",
              {
                attrs: { href: "https://router.vuejs.org/", targte: "_blank" }
              },
              [_vm._v("vue-router")]
            ),
            _vm._v(" you can do them simply by adding the property "),
            _c("a", { attrs: { href: "https://router.vuejs.org/api/#to" } }, [
              _vm._v("to")
            ]),
            _vm._v(" as if it were a vue-router link.\n            "),
            _c("br"),
            _vm._v(
              "\n            In case you need an external link or normal html, simply do it with the href property"
            )
          ])
        ]
      ),
      _vm._v(" "),
      _c(
        "vs-alert",
        {
          staticClass: "mb-1",
          attrs: { color: "primary", icon: "new_releases", active: "true" }
        },
        [
          _c("p", [
            _vm._v(
              "To make the link is in an active state we have the property "
            ),
            _c("code", [_vm._v("v-model")])
          ])
        ]
      ),
      _vm._v(" "),
      _c("div", { staticClass: "mt-5" }, [
        _c(
          "div",
          { attrs: { id: "parentx-demo-1" } },
          [
            _c(
              "vs-button",
              {
                attrs: { color: "primary", type: "filled" },
                on: {
                  click: function($event) {
                    _vm.active = !_vm.active
                  }
                }
              },
              [_vm._v("Open Sidebar")]
            ),
            _vm._v(" "),
            _c(
              "vs-sidebar",
              {
                staticClass: "sidebarx sidebarpage",
                attrs: {
                  parent: "body",
                  "default-index": "1",
                  color: "primary",
                  spacer: ""
                },
                model: {
                  value: _vm.active,
                  callback: function($$v) {
                    _vm.active = $$v
                  },
                  expression: "active"
                }
              },
              [
                _c(
                  "div",
                  {
                    staticClass: "header-sidebar",
                    attrs: { slot: "header" },
                    slot: "header"
                  },
                  [
                    _c("vs-avatar", {
                      attrs: {
                        size: "70px",
                        src: "https://randomuser.me/api/portraits/men/85.jpg"
                      }
                    }),
                    _vm._v(" "),
                    _c(
                      "h4",
                      [
                        _vm._v(
                          "\n                            My Name\n                            "
                        ),
                        _c("vs-button", {
                          attrs: {
                            color: "primary",
                            icon: "more_horiz",
                            type: "flat"
                          }
                        })
                      ],
                      1
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "vs-sidebar-item",
                  { attrs: { index: "1", icon: "question_answer" } },
                  [
                    _vm._v(
                      "\n                        Dashboard\n                    "
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "vs-sidebar-item",
                  { attrs: { index: "2", icon: "gavel" } },
                  [
                    _vm._v(
                      "\n                        History\n                    "
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "vs-divider",
                  { attrs: { icon: "person", position: "left" } },
                  [
                    _vm._v(
                      "\n                        User\n                    "
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "vs-sidebar-item",
                  { attrs: { index: "3", icon: "verified_user" } },
                  [
                    _vm._v(
                      "\n                        Configurations\n                    "
                    )
                  ]
                ),
                _vm._v(" "),
                _c(
                  "vs-sidebar-item",
                  { attrs: { index: "4", icon: "account_box" } },
                  [
                    _vm._v(
                      "\n                        Profile\n                    "
                    )
                  ]
                ),
                _vm._v(" "),
                _c("vs-sidebar-item", { attrs: { index: "5" } }, [
                  _vm._v("\n                        Card\n                    ")
                ]),
                _vm._v(" "),
                _c(
                  "div",
                  {
                    staticClass: "footer-sidebar",
                    attrs: { slot: "footer" },
                    slot: "footer"
                  },
                  [
                    _c(
                      "vs-button",
                      {
                        attrs: { icon: "reply", color: "danger", type: "flat" }
                      },
                      [_vm._v("log out")]
                    ),
                    _vm._v(" "),
                    _c("vs-button", {
                      attrs: {
                        icon: "settings",
                        color: "primary",
                        type: "border"
                      }
                    })
                  ],
                  1
                )
              ],
              1
            )
          ],
          1
        )
      ]),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n\n  <div id="parentx-demo-1">\n\n    <vs-button @click="active=!active" color="primary" type="filled">Open Sidebar</vs-button>\n    <vs-sidebar parent="body" default-index="1"  color="primary" class="sidebarx" spacer v-model="active">\n\n      <div class="header-sidebar" slot="header">\n        <vs-avatar  size="70px" src="https://randomuser.me/api/portraits/men/85.jpg"/>\n\n        <h4>\n          My Name\n          <vs-button color="primary" icon="more_horiz" type="flat"></vs-button>\n        </h4>\n\n      </div>\n\n      <vs-sidebar-item index="1" icon="question_answer"> Dashboard </vs-sidebar-item>\n      <vs-sidebar-item index="2" icon="gavel"> History </vs-sidebar-item>\n\n      <vs-divider icon="person" position="left"> User </vs-divider>\n\n      <vs-sidebar-item index="3" icon="verified_user"> Configurations </vs-sidebar-item>\n      <vs-sidebar-item index="4" icon="account_box"> Profile </vs-sidebar-item>\n      <vs-sidebar-item index="5" > Card </vs-sidebar-item>\n\n      <div class="footer-sidebar" slot="footer">\n        <vs-button icon="reply" color="danger" type="flat">log out</vs-button>\n        <vs-button icon="settings" color="primary" type="border"></vs-button>\n      </div>\n\n    </vs-sidebar>\n  </div>\n\n</template>\n\n<script>\nexport default {\n  data:()=>({\n    active:false,\n  })\n}\n</script>\n\n<style lang="scss">\n.header-sidebar {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  flex-direction: column;\n  width: 100%;\n  h4 {\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    width: 100%;\n    > button {\n      margin-left: 10px;\n    }\n  }\n}\n\n.footer-sidebar {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  width: 100%;\n  > button {\n    border: 0px solid rgba(0, 0, 0, 0) !important;\n    border-left: 1px solid rgba(0, 0, 0, 0.07) !important;\n    border-radius: 0px !important;\n  }\n}\n</style>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarGroupCollapsed.vue?vue&type=template&id=2a9927d6&":
/*!*************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/sidebar/SidebarGroupCollapsed.vue?vue&type=template&id=2a9927d6& ***!
  \*************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Group Collapsed", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v("You can have groups of sub menus with the component "),
        _c("code", [_vm._v("vs-sidebar-group")]),
        _vm._v(" that as a required parameter we have the "),
        _c("code", [_vm._v("title")]),
        _vm._v(
          ", you can add as many groups as you need, including internally from the same component"
        )
      ]),
      _vm._v(" "),
      _c(
        "vs-alert",
        {
          staticClass: "mt-5",
          attrs: { color: "primary", icon: "new_releases", active: "true" }
        },
        [
          _c("p", [
            _vm._v(
              "By default the component is closed but if you need to initialize open you can use the property "
            ),
            _c("code", [_vm._v("open")])
          ])
        ]
      ),
      _vm._v(" "),
      _c("div", { staticClass: "mt-5" }, [
        _c(
          "div",
          { attrs: { id: "parentx-demo-4" } },
          [
            _c(
              "vs-button",
              {
                attrs: { color: "primary", type: "filled" },
                on: {
                  click: function($event) {
                    _vm.active = !_vm.active
                  }
                }
              },
              [_vm._v("Open Sidebar")]
            ),
            _vm._v(" "),
            _c(
              "vs-sidebar",
              {
                staticClass: "sidebarx sidebarpage",
                attrs: {
                  parent: "body",
                  "default-index": "1",
                  color: "primary",
                  spacer: ""
                },
                model: {
                  value: _vm.active,
                  callback: function($$v) {
                    _vm.active = $$v
                  },
                  expression: "active"
                }
              },
              [
                _c(
                  "div",
                  {
                    staticClass: "header-sidebar",
                    attrs: { slot: "header" },
                    slot: "header"
                  },
                  [
                    _c("vs-avatar", {
                      attrs: {
                        size: "70px",
                        src: "https://randomuser.me/api/portraits/men/85.jpg"
                      }
                    }),
                    _vm._v(" "),
                    _c(
                      "h4",
                      [
                        _vm._v("\n\t\t\t\t\t\t\tMy Name\n\t\t\t\t\t\t\t"),
                        _c("vs-button", {
                          attrs: {
                            color: "primary",
                            icon: "more_horiz",
                            type: "flat"
                          }
                        })
                      ],
                      1
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "vs-sidebar-group",
                  { attrs: { title: "Aplication" } },
                  [
                    _c(
                      "vs-sidebar-item",
                      { attrs: { index: "1", icon: "question_answer" } },
                      [_vm._v(" Dashboard ")]
                    ),
                    _vm._v(" "),
                    _c(
                      "vs-sidebar-group",
                      { attrs: { title: "Store" } },
                      [
                        _c(
                          "vs-sidebar-item",
                          { attrs: { index: "2.1", icon: "store" } },
                          [_vm._v(" Store ")]
                        ),
                        _vm._v(" "),
                        _c(
                          "vs-sidebar-item",
                          { attrs: { index: "2.2", icon: "nature_people" } },
                          [_vm._v(" Nature ")]
                        ),
                        _vm._v(" "),
                        _c(
                          "vs-sidebar-item",
                          { attrs: { index: "2.3", icon: "style" } },
                          [_vm._v(" Style ")]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "vs-sidebar-item",
                      { attrs: { index: "2", icon: "gavel" } },
                      [_vm._v(" History ")]
                    ),
                    _vm._v(" "),
                    _c(
                      "vs-sidebar-item",
                      { attrs: { index: "3", icon: "https" } },
                      [_vm._v(" Security ")]
                    ),
                    _vm._v(" "),
                    _c(
                      "vs-sidebar-item",
                      { attrs: { index: "4", icon: "help" } },
                      [_vm._v(" Help ")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "vs-divider",
                  { attrs: { icon: "person", position: "left" } },
                  [_vm._v(" User ")]
                ),
                _vm._v(" "),
                _c(
                  "vs-sidebar-item",
                  { attrs: { index: "5", icon: "verified_user" } },
                  [_vm._v(" Configurations ")]
                ),
                _vm._v(" "),
                _c(
                  "vs-sidebar-item",
                  { attrs: { index: "6", icon: "account_box" } },
                  [_vm._v(" Profile ")]
                ),
                _vm._v(" "),
                _c(
                  "div",
                  {
                    staticClass: "footer-sidebar",
                    attrs: { slot: "footer" },
                    slot: "footer"
                  },
                  [
                    _c(
                      "vs-button",
                      {
                        attrs: { icon: "reply", color: "danger", type: "flat" }
                      },
                      [_vm._v("log out")]
                    ),
                    _vm._v(" "),
                    _c("vs-button", {
                      attrs: {
                        icon: "settings",
                        color: "primary",
                        type: "border"
                      }
                    })
                  ],
                  1
                )
              ],
              1
            )
          ],
          1
        )
      ]),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template lang="html">\n\n  <div id="parentx-demo-4">\n\n    <vs-button @click="active=!active" color="primary" type="filled">Open Sidebar</vs-button>\n    <vs-sidebar parent="body" default-index="1"  color="primary" class="sidebarx" spacer v-model="active">\n\n      <div class="header-sidebar" slot="header">\n        <vs-avatar  size="70px" src="https://randomuser.me/api/portraits/men/85.jpg"/>\n        <h4>\n          My Name\n          <vs-button color="primary" icon="more_horiz" type="flat"></vs-button>\n        </h4>\n\n      </div>\n      <vs-sidebar-group title="Aplication">\n        <vs-sidebar-item index="1" icon="question_answer"> Dashboard </vs-sidebar-item>\n\n        <vs-sidebar-group title="Store">\n          <vs-sidebar-item index="2.1" icon="store"> Store </vs-sidebar-item>\n          <vs-sidebar-item index="2.2" icon="nature_people"> Nature </vs-sidebar-item>\n          <vs-sidebar-item index="2.3" icon="style"> Style </vs-sidebar-item>\n        </vs-sidebar-group>\n\n        <vs-sidebar-item index="2" icon="gavel"> History </vs-sidebar-item>\n        <vs-sidebar-item index="3" icon="https"> Security </vs-sidebar-item>\n        <vs-sidebar-item index="4" icon="help"> Help </vs-sidebar-item>\n      </vs-sidebar-group>\n\n\n      <vs-divider icon="person" position="left"> User </vs-divider>\n\n      <vs-sidebar-item index="5" icon="verified_user"> Configurations </vs-sidebar-item>\n      <vs-sidebar-item index="6" icon="account_box"> Profile </vs-sidebar-item>\n\n      <div class="footer-sidebar" slot="footer">\n        <vs-button icon="reply" color="danger" type="flat">log out</vs-button>\n        <vs-button icon="settings" color="primary" type="border"></vs-button>\n      </div>\n\n    </vs-sidebar>\n  </div>\n\n</template>\n\n<script>\nexport default {\n  data:()=>({\n    active:false,\n  })\n}\n</script>\n\n<style lang="scss">\n.header-sidebar {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  flex-direction: column;\n  width: 100%;\n  h4 {\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    width: 100%;\n    > button {\n      margin-left: 10px;\n    }\n  }\n}\n\n.footer-sidebar {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  width: 100%;\n  > button {\n    border: 0px solid rgba(0, 0, 0, 0) !important;\n    border-left: 1px solid rgba(0, 0, 0, 0.07) !important;\n    border-radius: 0px !important;\n  }\n}\n</style>\n\t\t'
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarParent.vue?vue&type=template&id=63e67627&":
/*!*****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/sidebar/SidebarParent.vue?vue&type=template&id=63e67627& ***!
  \*****************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    {
      staticClass: "overflow-hidden",
      attrs: { title: "Parent", "code-toggler": "" }
    },
    [
      _c("p", [
        _vm._v("You can change the parent of the sidebar with the property "),
        _c("code", [_vm._v("parent")]),
        _vm._v(" that as a value requires an element of the DOM ("),
        _c("strong", [_vm._v("#idx, .classx")]),
        _vm._v(") or a reference of Vuejs as "),
        _c("code", [_vm._v("$refs.myrefContent")])
      ]),
      _vm._v(" "),
      _c(
        "vs-alert",
        {
          staticClass: "my-5",
          attrs: { color: "primary", icon: "new_releases", active: "true" }
        },
        [_c("p", [_vm._v("By default the parent of the sidebar is the body")])]
      ),
      _vm._v(" "),
      _c(
        "vs-alert",
        {
          staticClass: "mb-5",
          attrs: { color: "primary", icon: "new_releases", active: "true" }
        },
        [
          _c("p", [
            _vm._v("You can remove dark background(overlay) by setting "),
            _c("code", [_vm._v("hidden-background")]),
            _vm._v(" prop to "),
            _c("code", [_vm._v("true")])
          ])
        ]
      ),
      _vm._v(" "),
      _c("div", { attrs: { slot: "no-body-bottom" }, slot: "no-body-bottom" }, [
        _c(
          "div",
          {
            staticClass: "relative",
            staticStyle: { height: "500px" },
            attrs: { id: "parentx-demo-2" }
          },
          [
            _c(
              "vs-button",
              {
                staticClass: "ml-6",
                attrs: { color: "primary", type: "filled" },
                on: {
                  click: function($event) {
                    _vm.active = !_vm.active
                  }
                }
              },
              [_vm._v("Open Sidebar")]
            ),
            _vm._v(" "),
            _c(
              "vs-sidebar",
              {
                staticClass:
                  "sidebarx sidebarpage sidebar-demo-parent bordered-sidebar",
                attrs: {
                  parent: "#parentx-demo-2",
                  "hidden-background": true,
                  "default-index": "1",
                  color: "primary",
                  spacer: ""
                },
                model: {
                  value: _vm.active,
                  callback: function($$v) {
                    _vm.active = $$v
                  },
                  expression: "active"
                }
              },
              [
                _c(
                  "div",
                  {
                    staticClass: "header-sidebar",
                    attrs: { slot: "header" },
                    slot: "header"
                  },
                  [
                    _c("vs-avatar", {
                      attrs: {
                        size: "70px",
                        src: "https://randomuser.me/api/portraits/men/85.jpg"
                      }
                    }),
                    _vm._v(" "),
                    _c(
                      "h4",
                      [
                        _vm._v("\n\t\t\t\t\t\t\tMy Name\n\t\t\t\t\t\t\t"),
                        _c("vs-button", {
                          attrs: {
                            color: "primary",
                            icon: "more_horiz",
                            type: "flat"
                          }
                        })
                      ],
                      1
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "vs-sidebar-item",
                  { attrs: { index: "1", icon: "question_answer" } },
                  [_vm._v(" Dashboard ")]
                ),
                _vm._v(" "),
                _c(
                  "vs-sidebar-item",
                  { attrs: { index: "2", icon: "gavel" } },
                  [_vm._v(" History ")]
                ),
                _vm._v(" "),
                _c(
                  "vs-divider",
                  { attrs: { icon: "person", position: "left" } },
                  [_vm._v(" User ")]
                ),
                _vm._v(" "),
                _c(
                  "vs-sidebar-item",
                  { attrs: { index: "3", icon: "verified_user" } },
                  [_vm._v(" Configurations ")]
                ),
                _vm._v(" "),
                _c(
                  "vs-sidebar-item",
                  { attrs: { index: "4", icon: "account_box" } },
                  [_vm._v(" Profile ")]
                ),
                _vm._v(" "),
                _c("vs-sidebar-item", { attrs: { index: "5" } }, [
                  _vm._v(" Card ")
                ]),
                _vm._v(" "),
                _c(
                  "div",
                  {
                    staticClass: "footer-sidebar",
                    attrs: { slot: "footer" },
                    slot: "footer"
                  },
                  [
                    _c(
                      "vs-button",
                      {
                        attrs: { icon: "reply", color: "danger", type: "flat" }
                      },
                      [_vm._v("log out")]
                    ),
                    _vm._v(" "),
                    _c("vs-button", {
                      attrs: {
                        icon: "settings",
                        color: "primary",
                        type: "border"
                      }
                    })
                  ],
                  1
                )
              ],
              1
            )
          ],
          1
        )
      ]),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n\n  <div id="parentx-demo-2">\n\n    <vs-button @click="active=!active" color="primary" type="filled">Open Sidebar</vs-button>\n    <vs-sidebar parent="#parentx-demo-2" :hidden-background="true" default-index="1"  color="primary" class="sidebarx" spacer v-model="active">\n\n      <div class="header-sidebar" slot="header">\n        <vs-avatar  size="70px" src="https://randomuser.me/api/portraits/men/85.jpg"/>\n        <h4>\n          My Name\n          <vs-button color="primary" icon="more_horiz" type="flat"></vs-button>\n        </h4>\n\n      </div>\n\n      <vs-sidebar-item index="1" icon="question_answer"> Dashboard </vs-sidebar-item>\n      <vs-sidebar-item index="2" icon="gavel"> History </vs-sidebar-item>\n\n      <vs-divider icon="person" position="left"> User </vs-divider>\n\n      <vs-sidebar-item index="3" icon="verified_user"> Configurations </vs-sidebar-item>\n      <vs-sidebar-item index="4" icon="account_box"> Profile </vs-sidebar-item>\n      <vs-sidebar-item index="5" > Card </vs-sidebar-item>\n\n      <div class="footer-sidebar" slot="footer">\n        <vs-button icon="reply" color="danger" type="flat">log out</vs-button>\n        <vs-button icon="settings" color="primary" type="border"></vs-button>\n      </div>\n    </vs-sidebar>\n  </div>\n\n</template>\n\n<script>\nexport default {\n  data:()=>({\n    active:false,\n  })\n}\n</script>\n\n<style lang="scss">\n#parentx {\n  overflow: hidden;\n  height: 500px;\n  position: relative;\n}\n\n.header-sidebar {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  flex-direction: column;\n  width: 100%;\n  h4 {\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    width: 100%;\n    > button {\n      margin-left: 10px;\n    }\n  }\n}\n\n.footer-sidebar {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  width: 100%;\n  > button {\n    border: 0px solid rgba(0, 0, 0, 0) !important;\n    border-left: 1px solid rgba(0, 0, 0, 0.07) !important;\n    border-radius: 0px !important;\n  }\n}\n</style>\n\t\t'
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarReduceExpand.vue?vue&type=template&id=39d15e5d&":
/*!***********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/sidebar/SidebarReduceExpand.vue?vue&type=template&id=39d15e5d& ***!
  \***********************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Reduce and Expand", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v("You can have a reduced sidebar with the "),
        _c("code", [_vm._v("reduce")]),
        _vm._v(
          " property which by default makes the sidebar look reduced and when hover expands, if you do not want the functionality to expand when hovering you can remove it with the "
        ),
        _c("code", [_vm._v("reduce-not-hover-expand")]),
        _vm._v(" property")
      ]),
      _vm._v(" "),
      _c(
        "vs-alert",
        {
          staticClass: "mt-5",
          attrs: { color: "primary", icon: "new_releases", active: "true" }
        },
        [
          _c("p", [
            _vm._v(
              "You can remove the bounce animation by opening the sidebar with the prop "
            ),
            _c("code", [_vm._v("reduce-not-rebound")])
          ])
        ]
      ),
      _vm._v(" "),
      _c("div", { staticClass: "mt-5" }, [
        _c(
          "div",
          { attrs: { id: "parentx-demo-6" } },
          [
            _c(
              "vs-button",
              {
                staticClass: "mr-4",
                attrs: { color: "success", type: "gradient" },
                on: {
                  click: function($event) {
                    ;(_vm.active = !_vm.active), (_vm.notExpand = false)
                  }
                }
              },
              [_vm._v("Open Sidebar Reduce-expand")]
            ),
            _vm._v(" "),
            _c(
              "vs-button",
              {
                staticClass: "mt-4",
                attrs: { color: "success", type: "gradient" },
                on: {
                  click: function($event) {
                    ;(_vm.active = !_vm.active), (_vm.notExpand = true)
                  }
                }
              },
              [_vm._v("Open Sidebar Reduce-only")]
            ),
            _vm._v(" "),
            _c(
              "vs-sidebar",
              {
                staticClass: "sidebarx sidebarpage",
                attrs: {
                  reduce: _vm.reduce,
                  "reduce-not-hover-expand": _vm.notExpand,
                  parent: "body",
                  "default-index": "1",
                  color: "success",
                  spacer: ""
                },
                model: {
                  value: _vm.active,
                  callback: function($$v) {
                    _vm.active = $$v
                  },
                  expression: "active"
                }
              },
              [
                _c(
                  "div",
                  {
                    staticClass: "header-sidebar",
                    attrs: { slot: "header" },
                    slot: "header"
                  },
                  [
                    _c("vs-avatar", {
                      attrs: {
                        size: "70px",
                        src: "https://randomuser.me/api/portraits/men/85.jpg"
                      }
                    })
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "vs-sidebar-group",
                  { attrs: { open: "", title: "Application" } },
                  [
                    _c(
                      "vs-sidebar-item",
                      {
                        attrs: { index: "1", icon: "menu" },
                        on: {
                          click: function($event) {
                            _vm.reduce = !_vm.reduce
                          }
                        }
                      },
                      [_vm._v(" Toggle Sidebar ")]
                    ),
                    _vm._v(" "),
                    _c(
                      "vs-sidebar-item",
                      { attrs: { index: "5", icon: "verified_user" } },
                      [_vm._v(" Configurations ")]
                    ),
                    _vm._v(" "),
                    _c(
                      "vs-sidebar-group",
                      { attrs: { title: "Store" } },
                      [
                        _c(
                          "vs-sidebar-item",
                          { attrs: { index: "2.1", icon: "store" } },
                          [_vm._v(" Store ")]
                        ),
                        _vm._v(" "),
                        _c(
                          "vs-sidebar-item",
                          { attrs: { index: "2.2", icon: "nature_people" } },
                          [_vm._v(" Nature ")]
                        ),
                        _vm._v(" "),
                        _c(
                          "vs-sidebar-item",
                          { attrs: { index: "2.3", icon: "style" } },
                          [_vm._v(" Style ")]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "vs-sidebar-item",
                      { attrs: { index: "2", icon: "gavel" } },
                      [_vm._v(" History ")]
                    ),
                    _vm._v(" "),
                    _c(
                      "vs-sidebar-item",
                      { attrs: { index: "3", icon: "https" } },
                      [_vm._v(" Security ")]
                    ),
                    _vm._v(" "),
                    _c(
                      "vs-sidebar-item",
                      { attrs: { index: "4", icon: "help" } },
                      [_vm._v(" Help\n\t\t\t\t\t\t")]
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "vs-divider",
                  { attrs: { icon: "person", position: "left" } },
                  [_vm._v(" User ")]
                ),
                _vm._v(" "),
                _c(
                  "vs-sidebar-item",
                  { attrs: { index: "6", icon: "account_box" } },
                  [_vm._v(" Profile ")]
                ),
                _vm._v(" "),
                _c(
                  "div",
                  {
                    staticClass: "footer-sidebar",
                    attrs: { slot: "footer" },
                    slot: "footer"
                  },
                  [
                    _c("vs-button", {
                      attrs: {
                        icon: "settings",
                        color: "primary",
                        type: "border"
                      }
                    })
                  ],
                  1
                )
              ],
              1
            )
          ],
          1
        )
      ]),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n\n  <div id="parentx-demo-6">\n    <vs-button @click="active=!active, notExpand = false" color="success" type="filled">Open Sidebar Reduce-expand</vs-button>\n    <vs-button @click="active=!active, notExpand = true" color="success" type="filled">Open Sidebar Reduce-only</vs-button>\n\n    <vs-sidebar :reduce="reduce" :reduce-not-hover-expand="notExpand" parent="body" default-index="1"  color="success" class="sidebarx" spacer v-model="active">\n\n      <div class="header-sidebar" slot="header">\n        <vs-avatar  size="70px" src="https://randomuser.me/api/portraits/men/85.jpg"/>\n      </div>\n      <vs-sidebar-group open title="Application">\n        <vs-sidebar-item index="1" icon="menu" @click="reduce=!reduce"> Toggle Sidebar </vs-sidebar-item>\n        <vs-sidebar-item index="5" icon="verified_user"> Configurations </vs-sidebar-item>\n\n        <vs-sidebar-group title="Store">\n          <vs-sidebar-item index="2.1" icon="store"> Store </vs-sidebar-item>\n          <vs-sidebar-item index="2.2" icon="nature_people"> Nature </vs-sidebar-item>\n          <vs-sidebar-item index="2.3" icon="style"> Style </vs-sidebar-item>\n        </vs-sidebar-group>\n\n        <vs-sidebar-item index="2" icon="gavel"> History </vs-sidebar-item>\n        <vs-sidebar-item index="3" icon="https"> Security </vs-sidebar-item>\n        <vs-sidebar-item index="4" icon="help"> Help </vs-sidebar-item>\n      </vs-sidebar-group>\n\n\n      <vs-divider icon="person" position="left"> User </vs-divider>\n\n      <vs-sidebar-item index="6" icon="account_box"> Profile </vs-sidebar-item>\n\n      <div class="footer-sidebar" slot="footer">\n        <vs-button icon="settings" color="primary" type="border"></vs-button>\n      </div>\n    </vs-sidebar>\n  </div>\n\n</template>\n\n<script>\nexport default {\n  data:()=>({\n    active:false,\n    notExpand: false,\n    reduce: true\n  })\n}\n</script>\n\n<style lang="scss">\n.header-sidebar {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  flex-direction: column;\n  width: 100%;\n  h4 {\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    width: 100%;\n    > button {\n      margin-left: 10px;\n    }\n  }\n}\n\n.footer-sidebar {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  width: 100%;\n  > button {\n    border: 0px solid rgba(0, 0, 0, 0) !important;\n    border-left: 1px solid rgba(0, 0, 0, 0.07) !important;\n    border-radius: 0px !important;\n  }\n}\n</style>\n\t\t'
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarRight.vue?vue&type=template&id=1174d62f&":
/*!****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/sidebar/SidebarRight.vue?vue&type=template&id=1174d62f& ***!
  \****************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Open on the right", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v(
          "You can also choose where you'd like the sidebar to appear, right or left? By default, a sidebar will be located on the left of the screen but sometimes, a right-screened sidebar is really useful!"
        )
      ]),
      _vm._v(" "),
      _c(
        "vs-alert",
        {
          staticClass: "mb-1",
          attrs: { icon: "warning", active: "true", color: "warning" }
        },
        [
          _c("span", [
            _vm._v("A "),
            _c("code", [_vm._v("static")]),
            _vm._v(" sidebar will not appear on the right.")
          ])
        ]
      ),
      _vm._v(" "),
      _c("div", { staticClass: "mt-5" }, [
        _c(
          "div",
          { attrs: { id: "parentx-demo-5" } },
          [
            _c(
              "vs-button",
              {
                attrs: { color: "primary", type: "filled" },
                on: {
                  click: function($event) {
                    _vm.active = !_vm.active
                  }
                }
              },
              [_vm._v("Open Sidebar")]
            ),
            _vm._v(" "),
            _c(
              "vs-sidebar",
              {
                staticClass: "sidebarx sidebarpage",
                attrs: {
                  "position-right": "",
                  parent: "body",
                  "default-index": "1",
                  color: "primary",
                  spacer: ""
                },
                model: {
                  value: _vm.active,
                  callback: function($$v) {
                    _vm.active = $$v
                  },
                  expression: "active"
                }
              },
              [
                _c(
                  "div",
                  {
                    staticClass: "header-sidebar",
                    attrs: { slot: "header" },
                    slot: "header"
                  },
                  [
                    _c("vs-avatar", {
                      attrs: {
                        size: "70px",
                        src: "https://randomuser.me/api/portraits/men/85.jpg"
                      }
                    }),
                    _vm._v(" "),
                    _c(
                      "h4",
                      [
                        _vm._v("\n\t\t\t\t\t\t\tMy Name\n\t\t\t\t\t\t\t"),
                        _c("vs-button", {
                          attrs: {
                            color: "primary",
                            icon: "more_horiz",
                            type: "flat"
                          }
                        })
                      ],
                      1
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "vs-sidebar-item",
                  { attrs: { index: "1", icon: "question_answer" } },
                  [_vm._v(" Dashboard ")]
                ),
                _vm._v(" "),
                _c(
                  "vs-sidebar-item",
                  { attrs: { index: "2", icon: "gavel" } },
                  [_vm._v(" History ")]
                ),
                _vm._v(" "),
                _c(
                  "vs-divider",
                  { attrs: { icon: "person", position: "left" } },
                  [_vm._v(" User ")]
                ),
                _vm._v(" "),
                _c(
                  "vs-sidebar-item",
                  { attrs: { index: "3", icon: "verified_user" } },
                  [_vm._v(" Configurations ")]
                ),
                _vm._v(" "),
                _c(
                  "vs-sidebar-item",
                  { attrs: { index: "4", icon: "account_box" } },
                  [_vm._v(" Profile ")]
                ),
                _vm._v(" "),
                _c("vs-sidebar-item", { attrs: { index: "5" } }, [
                  _vm._v(" Card ")
                ]),
                _vm._v(" "),
                _c(
                  "div",
                  {
                    staticClass: "footer-sidebar",
                    attrs: { slot: "footer" },
                    slot: "footer"
                  },
                  [
                    _c(
                      "vs-button",
                      {
                        attrs: { icon: "reply", color: "danger", type: "flat" }
                      },
                      [_vm._v("log out")]
                    ),
                    _vm._v(" "),
                    _c("vs-button", {
                      attrs: {
                        icon: "settings",
                        color: "primary",
                        type: "border"
                      }
                    })
                  ],
                  1
                )
              ],
              1
            )
          ],
          1
        )
      ]),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n\n  <div id="parentx-demo-5">\n\n    <vs-button @click="active=!active" color="primary" type="filled">Open Sidebar</vs-button>\n    <vs-sidebar position-right  parent="body" default-index="1"  color="primary" class="sidebarx" spacer v-model="active">\n\n      <div class="header-sidebar" slot="header">\n        <vs-avatar  size="70px" src="https://randomuser.me/api/portraits/men/85.jpg"/>\n        <h4>\n          My Name\n          <vs-button color="primary" icon="more_horiz" type="flat"></vs-button>\n        </h4>\n\n      </div>\n\n      <vs-sidebar-item index="1" icon="question_answer"> Dashboard </vs-sidebar-item>\n      <vs-sidebar-item index="2" icon="gavel"> History </vs-sidebar-item>\n\n      <vs-divider icon="person" position="left"> User </vs-divider>\n\n      <vs-sidebar-item index="3" icon="verified_user"> Configurations </vs-sidebar-item>\n      <vs-sidebar-item index="4" icon="account_box"> Profile </vs-sidebar-item>\n      <vs-sidebar-item index="5" > Card </vs-sidebar-item>\n\n      <div class="footer-sidebar" slot="footer">\n        <vs-button icon="reply" color="danger" type="flat">log out</vs-button>\n        <vs-button icon="settings" color="primary" type="border"></vs-button>\n      </div>\n    </vs-sidebar>\n  </div>\n\n</template>\n\n<script>\nexport default {\n  data:()=>({\n    active:false,\n  })\n}\n</script>\n\n<style lang="scss">\n.header-sidebar {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  flex-direction: column;\n  width: 100%;\n  h4 {\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    width: 100%;\n    > button {\n      margin-left: 10px;\n    }\n  }\n}\n\n.footer-sidebar {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  width: 100%;\n  > button {\n    border: 0px solid rgba(0, 0, 0, 0) !important;\n    border-left: 1px solid rgba(0, 0, 0, 0.07) !important;\n    border-radius: 0px !important;\n  }\n}\n</style>\n\t\t'
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarStatic.vue?vue&type=template&id=6be8b9eb&":
/*!*****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/sidebar/SidebarStatic.vue?vue&type=template&id=6be8b9eb& ***!
  \*****************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Static", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v(
          "You can also use the sidebar in static mode with the property static"
        )
      ]),
      _vm._v(" "),
      _c(
        "vs-alert",
        {
          staticClass: "mt-5 mb-base",
          attrs: { color: "primary", icon: "new_releases", active: "true" }
        },
        [
          _c("p", [
            _vm._v(
              "when putting the sidebar in static mode its position becomes relative for better manipulation"
            )
          ])
        ]
      ),
      _vm._v(" "),
      _c("div", [
        _c(
          "div",
          {
            staticClass: "parentx-static relative",
            staticStyle: { height: "435px" }
          },
          [
            _c(
              "vs-sidebar",
              {
                staticClass: "sidebarx sidebarpage bordered-sidebar",
                attrs: {
                  "static-position": "",
                  "default-index": "1",
                  color: "primary",
                  spacer: ""
                },
                model: {
                  value: _vm.active,
                  callback: function($$v) {
                    _vm.active = $$v
                  },
                  expression: "active"
                }
              },
              [
                _c(
                  "div",
                  {
                    staticClass: "header-sidebar",
                    attrs: { slot: "header" },
                    slot: "header"
                  },
                  [
                    _c("vs-avatar", {
                      attrs: {
                        size: "70px",
                        src: "https://randomuser.me/api/portraits/men/85.jpg"
                      }
                    }),
                    _vm._v(" "),
                    _c(
                      "h4",
                      [
                        _vm._v("\n\t\t\t\t\t\t\tMy Name\n\t\t\t\t\t\t\t"),
                        _c("vs-button", {
                          attrs: {
                            color: "primary",
                            icon: "more_horiz",
                            type: "flat"
                          }
                        })
                      ],
                      1
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "vs-sidebar-item",
                  { attrs: { index: "1", icon: "question_answer" } },
                  [_vm._v(" Dashboard ")]
                ),
                _vm._v(" "),
                _c(
                  "vs-sidebar-item",
                  { attrs: { index: "2", icon: "gavel" } },
                  [_vm._v(" History ")]
                ),
                _vm._v(" "),
                _c(
                  "vs-divider",
                  { attrs: { icon: "person", position: "left" } },
                  [_vm._v(" User ")]
                ),
                _vm._v(" "),
                _c(
                  "vs-sidebar-item",
                  { attrs: { index: "3", icon: "verified_user" } },
                  [_vm._v(" Configurations ")]
                ),
                _vm._v(" "),
                _c(
                  "vs-sidebar-item",
                  { attrs: { index: "4", icon: "account_box" } },
                  [_vm._v(" Profile ")]
                ),
                _vm._v(" "),
                _c("vs-sidebar-item", { attrs: { index: "5" } }, [
                  _vm._v(" Card ")
                ]),
                _vm._v(" "),
                _c(
                  "div",
                  {
                    staticClass: "footer-sidebar",
                    attrs: { slot: "footer" },
                    slot: "footer"
                  },
                  [
                    _c(
                      "vs-button",
                      {
                        attrs: { icon: "reply", color: "danger", type: "flat" }
                      },
                      [_vm._v("log out")]
                    ),
                    _vm._v(" "),
                    _c("vs-button", {
                      attrs: {
                        icon: "settings",
                        color: "primary",
                        type: "border"
                      }
                    })
                  ],
                  1
                )
              ],
              1
            )
          ],
          1
        )
      ]),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n\n  <div class="parentx-static">\n    <vs-sidebar static-position default-index="1" color="primary" class="sidebarx" spacer v-model="active">\n\n      <div class="header-sidebar" slot="header">\n        <vs-avatar  size="70px" src="https://randomuser.me/api/portraits/men/85.jpg"/>\n        <h4>\n          My Name\n          <vs-button color="primary" icon="more_horiz" type="flat"></vs-button>\n        </h4>\n\n      </div>\n\n      <vs-sidebar-item index="1" icon="question_answer"> Dashboard </vs-sidebar-item>\n\n      <vs-sidebar-item index="2" icon="gavel"> History </vs-sidebar-item>\n\n      <vs-divider icon="person" position="left"> User </vs-divider>\n\n      <vs-sidebar-item index="3" icon="verified_user"> Configurations </vs-sidebar-item>\n      <vs-sidebar-item index="4" icon="account_box"> Profile </vs-sidebar-item>\n      <vs-sidebar-item index="5" > Card </vs-sidebar-item>\n\n      <div class="footer-sidebar" slot="footer">\n        <vs-button icon="reply" color="danger" type="flat">log out</vs-button>\n        <vs-button icon="settings" color="primary" type="border"></vs-button>\n      </div>\n\n    </vs-sidebar>\n  </div>\n\n</template>\n\n<script>\nexport default {\n  data:()=>({\n    active:false,\n  })\n}\n</script>\n\n<style lang="scss">\n.parentx-static {\n  overflow: hidden;\n  height: 500px;\n  position: relative;\n}\n\n.header-sidebar {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  flex-direction: column;\n  width: 100%;\n  h4 {\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    width: 100%;\n    > button {\n      margin-left: 10px;\n    }\n  }\n}\n\n.footer-sidebar {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  width: 100%;\n  > button {\n    border: 0px solid rgba(0, 0, 0, 0) !important;\n    border-left: 1px solid rgba(0, 0, 0, 0.07) !important;\n    border-radius: 0px !important;\n  }\n}\n</style>\n\t\t'
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/sidebar/Sidebar.vue":
/*!**********************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/sidebar/Sidebar.vue ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Sidebar_vue_vue_type_template_id_a92523c6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Sidebar.vue?vue&type=template&id=a92523c6& */ "./resources/js/src/views/components/vuesax/sidebar/Sidebar.vue?vue&type=template&id=a92523c6&");
/* harmony import */ var _Sidebar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Sidebar.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/vuesax/sidebar/Sidebar.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _Sidebar_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Sidebar.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/src/views/components/vuesax/sidebar/Sidebar.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Sidebar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Sidebar_vue_vue_type_template_id_a92523c6___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Sidebar_vue_vue_type_template_id_a92523c6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/sidebar/Sidebar.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/sidebar/Sidebar.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/sidebar/Sidebar.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Sidebar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Sidebar.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/Sidebar.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Sidebar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/sidebar/Sidebar.vue?vue&type=style&index=0&lang=scss&":
/*!********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/sidebar/Sidebar.vue?vue&type=style&index=0&lang=scss& ***!
  \********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Sidebar_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/style-loader!../../../../../../../node_modules/css-loader!../../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../node_modules/postcss-loader/src??ref--8-2!../../../../../../../node_modules/sass-loader/dist/cjs.js??ref--8-3!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Sidebar.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/Sidebar.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Sidebar_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Sidebar_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Sidebar_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Sidebar_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./resources/js/src/views/components/vuesax/sidebar/Sidebar.vue?vue&type=template&id=a92523c6&":
/*!*****************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/sidebar/Sidebar.vue?vue&type=template&id=a92523c6& ***!
  \*****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Sidebar_vue_vue_type_template_id_a92523c6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Sidebar.vue?vue&type=template&id=a92523c6& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/Sidebar.vue?vue&type=template&id=a92523c6&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Sidebar_vue_vue_type_template_id_a92523c6___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Sidebar_vue_vue_type_template_id_a92523c6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/sidebar/SidebarCustom.vue":
/*!****************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/sidebar/SidebarCustom.vue ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SidebarCustom_vue_vue_type_template_id_14353d6e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SidebarCustom.vue?vue&type=template&id=14353d6e& */ "./resources/js/src/views/components/vuesax/sidebar/SidebarCustom.vue?vue&type=template&id=14353d6e&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _SidebarCustom_vue_vue_type_template_id_14353d6e___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SidebarCustom_vue_vue_type_template_id_14353d6e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/sidebar/SidebarCustom.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/sidebar/SidebarCustom.vue?vue&type=template&id=14353d6e&":
/*!***********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/sidebar/SidebarCustom.vue?vue&type=template&id=14353d6e& ***!
  \***********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarCustom_vue_vue_type_template_id_14353d6e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SidebarCustom.vue?vue&type=template&id=14353d6e& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarCustom.vue?vue&type=template&id=14353d6e&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarCustom_vue_vue_type_template_id_14353d6e___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarCustom_vue_vue_type_template_id_14353d6e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/sidebar/SidebarDefault.vue":
/*!*****************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/sidebar/SidebarDefault.vue ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SidebarDefault_vue_vue_type_template_id_760b45d8___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SidebarDefault.vue?vue&type=template&id=760b45d8& */ "./resources/js/src/views/components/vuesax/sidebar/SidebarDefault.vue?vue&type=template&id=760b45d8&");
/* harmony import */ var _SidebarDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SidebarDefault.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/vuesax/sidebar/SidebarDefault.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _SidebarDefault_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SidebarDefault.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/src/views/components/vuesax/sidebar/SidebarDefault.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _SidebarDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SidebarDefault_vue_vue_type_template_id_760b45d8___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SidebarDefault_vue_vue_type_template_id_760b45d8___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/sidebar/SidebarDefault.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/sidebar/SidebarDefault.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/sidebar/SidebarDefault.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SidebarDefault.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarDefault.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/sidebar/SidebarDefault.vue?vue&type=style&index=0&lang=scss&":
/*!***************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/sidebar/SidebarDefault.vue?vue&type=style&index=0&lang=scss& ***!
  \***************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarDefault_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/style-loader!../../../../../../../node_modules/css-loader!../../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../node_modules/postcss-loader/src??ref--8-2!../../../../../../../node_modules/sass-loader/dist/cjs.js??ref--8-3!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SidebarDefault.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarDefault.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarDefault_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarDefault_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarDefault_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarDefault_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./resources/js/src/views/components/vuesax/sidebar/SidebarDefault.vue?vue&type=template&id=760b45d8&":
/*!************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/sidebar/SidebarDefault.vue?vue&type=template&id=760b45d8& ***!
  \************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarDefault_vue_vue_type_template_id_760b45d8___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SidebarDefault.vue?vue&type=template&id=760b45d8& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarDefault.vue?vue&type=template&id=760b45d8&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarDefault_vue_vue_type_template_id_760b45d8___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarDefault_vue_vue_type_template_id_760b45d8___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/sidebar/SidebarGroupCollapsed.vue":
/*!************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/sidebar/SidebarGroupCollapsed.vue ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SidebarGroupCollapsed_vue_vue_type_template_id_2a9927d6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SidebarGroupCollapsed.vue?vue&type=template&id=2a9927d6& */ "./resources/js/src/views/components/vuesax/sidebar/SidebarGroupCollapsed.vue?vue&type=template&id=2a9927d6&");
/* harmony import */ var _SidebarGroupCollapsed_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SidebarGroupCollapsed.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/vuesax/sidebar/SidebarGroupCollapsed.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SidebarGroupCollapsed_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SidebarGroupCollapsed_vue_vue_type_template_id_2a9927d6___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SidebarGroupCollapsed_vue_vue_type_template_id_2a9927d6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/sidebar/SidebarGroupCollapsed.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/sidebar/SidebarGroupCollapsed.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/sidebar/SidebarGroupCollapsed.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarGroupCollapsed_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SidebarGroupCollapsed.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarGroupCollapsed.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarGroupCollapsed_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/sidebar/SidebarGroupCollapsed.vue?vue&type=template&id=2a9927d6&":
/*!*******************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/sidebar/SidebarGroupCollapsed.vue?vue&type=template&id=2a9927d6& ***!
  \*******************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarGroupCollapsed_vue_vue_type_template_id_2a9927d6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SidebarGroupCollapsed.vue?vue&type=template&id=2a9927d6& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarGroupCollapsed.vue?vue&type=template&id=2a9927d6&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarGroupCollapsed_vue_vue_type_template_id_2a9927d6___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarGroupCollapsed_vue_vue_type_template_id_2a9927d6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/sidebar/SidebarParent.vue":
/*!****************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/sidebar/SidebarParent.vue ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SidebarParent_vue_vue_type_template_id_63e67627___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SidebarParent.vue?vue&type=template&id=63e67627& */ "./resources/js/src/views/components/vuesax/sidebar/SidebarParent.vue?vue&type=template&id=63e67627&");
/* harmony import */ var _SidebarParent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SidebarParent.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/vuesax/sidebar/SidebarParent.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SidebarParent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SidebarParent_vue_vue_type_template_id_63e67627___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SidebarParent_vue_vue_type_template_id_63e67627___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/sidebar/SidebarParent.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/sidebar/SidebarParent.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/sidebar/SidebarParent.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarParent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SidebarParent.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarParent.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarParent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/sidebar/SidebarParent.vue?vue&type=template&id=63e67627&":
/*!***********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/sidebar/SidebarParent.vue?vue&type=template&id=63e67627& ***!
  \***********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarParent_vue_vue_type_template_id_63e67627___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SidebarParent.vue?vue&type=template&id=63e67627& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarParent.vue?vue&type=template&id=63e67627&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarParent_vue_vue_type_template_id_63e67627___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarParent_vue_vue_type_template_id_63e67627___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/sidebar/SidebarReduceExpand.vue":
/*!**********************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/sidebar/SidebarReduceExpand.vue ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SidebarReduceExpand_vue_vue_type_template_id_39d15e5d___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SidebarReduceExpand.vue?vue&type=template&id=39d15e5d& */ "./resources/js/src/views/components/vuesax/sidebar/SidebarReduceExpand.vue?vue&type=template&id=39d15e5d&");
/* harmony import */ var _SidebarReduceExpand_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SidebarReduceExpand.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/vuesax/sidebar/SidebarReduceExpand.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SidebarReduceExpand_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SidebarReduceExpand_vue_vue_type_template_id_39d15e5d___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SidebarReduceExpand_vue_vue_type_template_id_39d15e5d___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/sidebar/SidebarReduceExpand.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/sidebar/SidebarReduceExpand.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/sidebar/SidebarReduceExpand.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarReduceExpand_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SidebarReduceExpand.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarReduceExpand.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarReduceExpand_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/sidebar/SidebarReduceExpand.vue?vue&type=template&id=39d15e5d&":
/*!*****************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/sidebar/SidebarReduceExpand.vue?vue&type=template&id=39d15e5d& ***!
  \*****************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarReduceExpand_vue_vue_type_template_id_39d15e5d___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SidebarReduceExpand.vue?vue&type=template&id=39d15e5d& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarReduceExpand.vue?vue&type=template&id=39d15e5d&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarReduceExpand_vue_vue_type_template_id_39d15e5d___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarReduceExpand_vue_vue_type_template_id_39d15e5d___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/sidebar/SidebarRight.vue":
/*!***************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/sidebar/SidebarRight.vue ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SidebarRight_vue_vue_type_template_id_1174d62f___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SidebarRight.vue?vue&type=template&id=1174d62f& */ "./resources/js/src/views/components/vuesax/sidebar/SidebarRight.vue?vue&type=template&id=1174d62f&");
/* harmony import */ var _SidebarRight_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SidebarRight.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/vuesax/sidebar/SidebarRight.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SidebarRight_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SidebarRight_vue_vue_type_template_id_1174d62f___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SidebarRight_vue_vue_type_template_id_1174d62f___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/sidebar/SidebarRight.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/sidebar/SidebarRight.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/sidebar/SidebarRight.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarRight_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SidebarRight.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarRight.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarRight_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/sidebar/SidebarRight.vue?vue&type=template&id=1174d62f&":
/*!**********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/sidebar/SidebarRight.vue?vue&type=template&id=1174d62f& ***!
  \**********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarRight_vue_vue_type_template_id_1174d62f___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SidebarRight.vue?vue&type=template&id=1174d62f& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarRight.vue?vue&type=template&id=1174d62f&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarRight_vue_vue_type_template_id_1174d62f___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarRight_vue_vue_type_template_id_1174d62f___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/sidebar/SidebarStatic.vue":
/*!****************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/sidebar/SidebarStatic.vue ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SidebarStatic_vue_vue_type_template_id_6be8b9eb___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SidebarStatic.vue?vue&type=template&id=6be8b9eb& */ "./resources/js/src/views/components/vuesax/sidebar/SidebarStatic.vue?vue&type=template&id=6be8b9eb&");
/* harmony import */ var _SidebarStatic_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SidebarStatic.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/vuesax/sidebar/SidebarStatic.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SidebarStatic_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SidebarStatic_vue_vue_type_template_id_6be8b9eb___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SidebarStatic_vue_vue_type_template_id_6be8b9eb___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/sidebar/SidebarStatic.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/sidebar/SidebarStatic.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/sidebar/SidebarStatic.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarStatic_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SidebarStatic.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarStatic.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarStatic_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/sidebar/SidebarStatic.vue?vue&type=template&id=6be8b9eb&":
/*!***********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/sidebar/SidebarStatic.vue?vue&type=template&id=6be8b9eb& ***!
  \***********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarStatic_vue_vue_type_template_id_6be8b9eb___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SidebarStatic.vue?vue&type=template&id=6be8b9eb& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/sidebar/SidebarStatic.vue?vue&type=template&id=6be8b9eb&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarStatic_vue_vue_type_template_id_6be8b9eb___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SidebarStatic_vue_vue_type_template_id_6be8b9eb___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);