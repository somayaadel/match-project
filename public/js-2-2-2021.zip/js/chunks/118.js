(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[118],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/package/edit.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/package/edit.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _axios_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../axios.js */ "./resources/js/src/axios.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
 // import CellRendererAdd from "./cell-renderer/CellRendererAdd.vue";

/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      roleName: "",
      featuresKey: 0,
      applications: [],
      features: [],
      fields: [],
      oldFields: [],
      roles: [],
      package_data: {
        name: "",
        price: "",
        application_id: "",
        AllFeature: [],
        fields: []
      },
      packageLogo: "",
      searchQuery: ""
    };
  },
  mounted: function mounted() {},
  created: function created() {
    this.getCreateData();
    this.getFeatures();
    this.getApplication();
    this.getPackageData();
  },
  computed: {
    application_id: function application_id() {
      return this.$store.state.application_id;
    }
  },
  methods: {
    getCreateData: function getCreateData() {
      var _this = this;

      _axios_js__WEBPACK_IMPORTED_MODULE_0__["default"].get("/api/package/create?application_id=" + this.application_id).then(function (res) {
        _this.features = res.data.features;
        _this.fields = res.data.fields;
        _this.roles = res.data.roles;
        _this.oldFields = JSON.parse(JSON.stringify(res.data.fields));
        console.log("fields : ", _this.fields);
      });
    },
    addSubcategory: function addSubcategory() {
      this.package_data.AllFeature.push({
        pivot: {}
      });
      this.featuresKey++;
    },
    removeSubcategory: function removeSubcategory(index) {
      this.package_data.AllFeature.splice(index, 1);
    },
    getFeatures: function getFeatures() {
      var _this2 = this;

      _axios_js__WEBPACK_IMPORTED_MODULE_0__["default"].get("/api/feature").then(function (res) {
        _this2.features = res.data.data;
      }).catch(function (err) {});
    },
    getApplication: function getApplication() {
      var _this3 = this;

      _axios_js__WEBPACK_IMPORTED_MODULE_0__["default"].get("/api/application").then(function (res) {
        _this3.applications = res.data.data;
        console.log("applications", _this3.applications);
      }).catch(function (err) {
        console.log(err);
      });
    },
    getPackageData: function getPackageData() {
      var _this4 = this;

      _axios_js__WEBPACK_IMPORTED_MODULE_0__["default"].get("/api/package/" + this.$route.params.id).then(function (res) {
        _this4.package_data = res.data.data;
        _this4.package_data.AllFeature = _this4.package_data.features;

        _this4.roleChanged();

        _this4.featuresKey++;

        _this4.updatePackageFields();
      });
    },
    updatePackageFields: function updatePackageFields() {
      var _this5 = this;

      this.fields.forEach(function (field) {
        _this5.package_data.fields.forEach(function (actualField) {
          if (field.id == actualField.id) {
            field.required = true;
          }
        });
      });
    },
    submitData: function submitData() {
      var _this6 = this;

      this.$validator.validateAll().then(function (res) {
        for (var i = 0; i < _this6.package_data.features.length; i++) {
          _this6.package_data.features[i].feature_id = _this6.package_data.features[i].pivot.feature_id;
          _this6.package_data.features[i].package_id = _this6.package_data.features[i].pivot.package_id;
          _this6.package_data.features[i].limitation = _this6.package_data.features[i].pivot.limitation;
        }

        _this6.package_data.fields = [];

        _this6.fields.forEach(function (element, index) {
          if (_this6.fields[index].required && !_this6.oldFields[index].required) {
            _this6.package_data.fields.push({
              field_id: _this6.fields[index].id
            });
          }
        });

        _this6.packageLogo = _this6.$refs.ufile.filesx[0];

        if (!_this6.$refs.ufile.filesx[0]) {
          _this6.sendPackagePutRequest();

          return;
        }

        var component = _this6;
        var reader = new FileReader();
        reader.readAsDataURL(_this6.packageLogo);

        reader.onload = function () {
          component.packageLogo = reader.result;
          component.package_data.logoFile = reader.result;
          component.sendPackagePutRequest();
        };
      });
    },
    sendPackagePutRequest: function sendPackagePutRequest() {
      var _this7 = this;

      _axios_js__WEBPACK_IMPORTED_MODULE_0__["default"].put("/api/package/" + this.$route.params.id, this.package_data).then(function (res) {
        console.log(res.data);

        _this7.$router.push({
          name: "packageList"
        }); // this.$router.go();

      }).catch(function (err) {
        console.log(err);
      });
    },
    roleChanged: function roleChanged() {
      var _this8 = this;

      this.roles.forEach(function (role) {
        if (role.id == _this8.package_data.role_id) _this8.roleName = role.name;
      });
    },
    showSuccess: function showSuccess(msg) {
      this.$vs.notify({
        color: "success",
        title: "package status",
        text: msg,
        position: "top-right"
      });
    },
    showError: function showError(msg) {
      this.$vs.notify({
        color: "danger",
        title: "Error",
        text: msg,
        position: "top-center"
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/package/edit.vue?vue&type=style&index=0&id=7ee20a86&scoped=true&lang=css&":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--7-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/package/edit.vue?vue&type=style&index=0&id=7ee20a86&scoped=true&lang=css& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".upload[data-v-7ee20a86] {\n  position: absolute;\n  z-index: 300;\n  top: 250px;\n  width: 240px;\n  height: 150px;\n  opacity: 0;\n}[dir=ltr] .upload[data-v-7ee20a86] {\n  left: 10px;\n}[dir=rtl] .upload[data-v-7ee20a86] {\n  right: 10px;\n}\n.logo[data-v-7ee20a86] {\n  position: relative;\n}\n[dir] .logo[data-v-7ee20a86] {\n  margin-top: 70px;\n}\n[dir] .up[data-v-7ee20a86] {\n  margin-top: 50;\n}\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/package/edit.vue?vue&type=style&index=0&id=7ee20a86&scoped=true&lang=css&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--7-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/package/edit.vue?vue&type=style&index=0&id=7ee20a86&scoped=true&lang=css& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../node_modules/css-loader??ref--7-1!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../node_modules/vue-loader/lib??vue-loader-options!./edit.vue?vue&type=style&index=0&id=7ee20a86&scoped=true&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/package/edit.vue?vue&type=style&index=0&id=7ee20a86&scoped=true&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/package/edit.vue?vue&type=template&id=7ee20a86&scoped=true&":
/*!**************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/package/edit.vue?vue&type=template&id=7ee20a86&scoped=true& ***!
  \**************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "container" }, [
    _vm._m(0),
    _vm._v(" "),
    _vm._m(1),
    _vm._v(" "),
    _c("div", { staticClass: "vx-row mt-5" }, [
      _c(
        "div",
        {
          staticClass:
            "vx-col w-full md:w-full sm:w-full lg:w-full xl:w-full flex flex-col lg:mb-0 md:mb-base sm:mb-0 mb-base mt-4"
        },
        [
          _c(
            "vx-card",
            { attrs: { title: "    " } },
            [
              _c("div", { staticClass: "vx-row mb-2" }, [
                _c(
                  "div",
                  { staticClass: "vx-col w-full" },
                  [
                    _c("vs-input", {
                      directives: [
                        {
                          name: "validate",
                          rawName: "v-validate",
                          value: "required",
                          expression: "'required'"
                        }
                      ],
                      staticClass: "w-full",
                      attrs: {
                        type: "text",
                        "icon-pack": "feather",
                        icon: "icon-user",
                        "icon-no-border": "",
                        "label-placeholder": " Name"
                      },
                      model: {
                        value: _vm.package_data.name,
                        callback: function($$v) {
                          _vm.$set(_vm.package_data, "name", $$v)
                        },
                        expression: "package_data.name"
                      }
                    })
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "vx-col w-full" },
                  [
                    _c("vs-input", {
                      directives: [
                        {
                          name: "validate",
                          rawName: "v-validate",
                          value: "required",
                          expression: "'required'"
                        }
                      ],
                      staticClass: "w-full",
                      attrs: {
                        type: "text",
                        "icon-pack": "feather",
                        icon: "icon-user",
                        "icon-no-border": "",
                        "label-placeholder": "Name in arabic"
                      },
                      model: {
                        value: _vm.package_data.name_ar,
                        callback: function($$v) {
                          _vm.$set(_vm.package_data, "name_ar", $$v)
                        },
                        expression: "package_data.name_ar"
                      }
                    })
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "vx-col w-full" },
                  [
                    _c("vs-input", {
                      directives: [
                        {
                          name: "validate",
                          rawName: "v-validate",
                          value: "required",
                          expression: "'required'"
                        }
                      ],
                      staticClass: "w-full",
                      attrs: {
                        type: "text",
                        "icon-pack": "feather",
                        icon: "icon-user",
                        "icon-no-border": "",
                        "label-placeholder": " price"
                      },
                      model: {
                        value: _vm.package_data.price,
                        callback: function($$v) {
                          _vm.$set(_vm.package_data, "price", $$v)
                        },
                        expression: "package_data.price"
                      }
                    })
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "vx-col w-full" },
                  [
                    _c("vs-input", {
                      directives: [
                        {
                          name: "validate",
                          rawName: "v-validate",
                          value: "required",
                          expression: "'required'"
                        }
                      ],
                      staticClass: "w-full",
                      attrs: {
                        type: "number",
                        "icon-pack": "feather",
                        icon: "icon-user",
                        "icon-no-border": "",
                        "label-placeholder": "duration in days"
                      },
                      model: {
                        value: _vm.package_data.duration,
                        callback: function($$v) {
                          _vm.$set(_vm.package_data, "duration", $$v)
                        },
                        expression: "package_data.duration"
                      }
                    })
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "vx-col w-full" },
                  [
                    _c(
                      "vs-select",
                      {
                        directives: [
                          {
                            name: "validate",
                            rawName: "v-validate",
                            value: "required",
                            expression: "'required'"
                          }
                        ],
                        staticClass: "vx-col w-1/3 selectExample",
                        attrs: {
                          label: "roles",
                          name: "role",
                          "label-placeholder": " role"
                        },
                        on: {
                          input: function($event) {
                            return _vm.roleChanged()
                          }
                        },
                        model: {
                          value: _vm.package_data.role_id,
                          callback: function($$v) {
                            _vm.$set(_vm.package_data, "role_id", $$v)
                          },
                          expression: "package_data.role_id"
                        }
                      },
                      _vm._l(_vm.roles, function(item, index) {
                        return _c("vs-select-item", {
                          key: index,
                          attrs: { value: item.id, text: item.name }
                        })
                      }),
                      1
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c("div", { staticClass: "vx-col w-full up" }, [
                  _c("div", { staticClass: "vx-row mb-6 upload" }, [
                    _c(
                      "div",
                      { staticClass: "vx-col md:w-100 w-full mt-5" },
                      [
                        _c("vs-upload", {
                          ref: "ufile",
                          attrs: {
                            limit: "1",
                            text: "edit Application Logo",
                            id: "ufile",
                            fileName: "CODE",
                            action: ""
                          }
                        })
                      ],
                      1
                    )
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "logo" }, [
                    _c("img", {
                      staticClass: "responsive card-img-top company-imgg p-3",
                      staticStyle: { width: "200px", height: "200px" },
                      attrs: {
                        src: _vm.package_data.logo
                          ? _vm.package_data.logo
                          : "https://idraksy.net/wp-content/uploads/2020/04/placeholder.png",
                        alt: "content-img"
                      }
                    })
                  ])
                ])
              ]),
              _vm._v(" "),
              _c(
                "vx-card",
                {
                  staticClass:
                    "vx-col w-full sm:w-full sm:w-full lg:w-full xl:w-full flex flex-col overflow-hidden my-5",
                  attrs: { title: "Add More Feature" }
                },
                [
                  [
                    _c("vs-button", {
                      directives: [
                        {
                          name: "validate",
                          rawName: "v-validate",
                          value: "required",
                          expression: "'required'"
                        }
                      ],
                      staticClass: "mb-2 float-right",
                      attrs: {
                        type: "gradient",
                        icon: "icon-plus",
                        "icon-pack": "feather",
                        radius: "",
                        color: "primary"
                      },
                      on: {
                        click: function($event) {
                          return _vm.addSubcategory()
                        }
                      }
                    }),
                    _vm._v(" "),
                    _c(
                      "div",
                      {
                        key: _vm.featuresKey,
                        staticClass: "vx-row w-full mb-2"
                      },
                      _vm._l(_vm.package_data.AllFeature, function(
                        item,
                        index
                      ) {
                        return _c(
                          "div",
                          { key: index, staticClass: "vx-col w-full" },
                          [
                            _c(
                              "div",
                              { staticClass: "vx-row w-full mb-2" },
                              [
                                _c(
                                  "vs-select",
                                  {
                                    directives: [
                                      {
                                        name: "validate",
                                        rawName: "v-validate",
                                        value: "required",
                                        expression: "'required'"
                                      }
                                    ],
                                    staticClass: "vx-col w-1/3 selectExample",
                                    attrs: {
                                      autocomplete: "",
                                      label: "features",
                                      name: "featureName",
                                      "label-placeholder": " featureName"
                                    },
                                    model: {
                                      value: item.pivot.feature_id,
                                      callback: function($$v) {
                                        _vm.$set(item.pivot, "feature_id", $$v)
                                      },
                                      expression: "item.pivot.feature_id"
                                    }
                                  },
                                  _vm._l(_vm.features, function(item, index) {
                                    return _c("vs-select-item", {
                                      key: index,
                                      attrs: { value: item.id, text: item.name }
                                    })
                                  }),
                                  1
                                ),
                                _vm._v(" "),
                                _c("vs-input", {
                                  directives: [
                                    {
                                      name: "validate",
                                      rawName: "v-validate",
                                      value: "required",
                                      expression: "'required'"
                                    }
                                  ],
                                  staticClass: "vx-col w-1/3",
                                  attrs: {
                                    type: "number",
                                    "icon-pack": "feather",
                                    icon: "icon-edit",
                                    "icon-no-border": "",
                                    "label-placeholder": "limitation"
                                  },
                                  model: {
                                    value: item.pivot.limitation,
                                    callback: function($$v) {
                                      _vm.$set(item.pivot, "limitation", $$v)
                                    },
                                    expression: "item.pivot.limitation"
                                  }
                                }),
                                _vm._v(" "),
                                _c("vs-button", {
                                  staticClass: "vx-col w-1/3 float-right mt-4",
                                  attrs: {
                                    type: "gradient",
                                    icon: "icon-trash",
                                    "icon-pack": "feather",
                                    radius: "",
                                    color: "danger"
                                  },
                                  on: {
                                    click: function($event) {
                                      return _vm.removeSubcategory(index)
                                    }
                                  }
                                })
                              ],
                              1
                            )
                          ]
                        )
                      }),
                      0
                    )
                  ]
                ],
                2
              ),
              _vm._v(" "),
              _vm.roleName == "talanted"
                ? _c(
                    "vx-card",
                    {
                      staticClass:
                        "vx-col w-full sm:w-full sm:w-full lg:w-full xl:w-full flex flex-col overflow-hidden my-5",
                      attrs: { title: "profile fields" }
                    },
                    [
                      _c(
                        "vx-card",
                        _vm._l(_vm.fields, function(item, index) {
                          return _c(
                            "vs-checkbox",
                            {
                              key: index,
                              attrs: {
                                color: "success",
                                disabled: _vm.oldFields[index].required == "1"
                              },
                              model: {
                                value: _vm.fields[index].required,
                                callback: function($$v) {
                                  _vm.$set(_vm.fields[index], "required", $$v)
                                },
                                expression: "fields[index].required"
                              }
                            },
                            [_vm._v(_vm._s(item.name))]
                          )
                        }),
                        1
                      )
                    ],
                    1
                  )
                : _vm._e(),
              _vm._v(" "),
              _c("div", { staticClass: "vx-row" }, [
                _c(
                  "div",
                  { staticClass: "vx-col w-full" },
                  [
                    _c(
                      "vs-button",
                      {
                        staticClass: "mr-3 mb-2",
                        attrs: { color: "danger" },
                        on: {
                          click: function($event) {
                            return _vm.submitData()
                          }
                        }
                      },
                      [_vm._v("Submit")]
                    )
                  ],
                  1
                )
              ])
            ],
            1
          )
        ],
        1
      )
    ])
  ])
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "vx-row" }, [
      _c("div", { staticClass: "vx-col w-3/4" }),
      _vm._v(" "),
      _c("div", { staticClass: "vx-col w-1/4" })
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "row px-3 w-1/2" }, [
      _c("h3", { staticClass: "text-title-grey title-patient py-5" }, [
        _vm._v("edit Package")
      ]),
      _vm._v(" "),
      _c("h1", { staticClass: "my-3 text-title-grey" }, [
        _vm._v("edit Package")
      ])
    ])
  }
]
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/package/edit.vue":
/*!*************************************************!*\
  !*** ./resources/js/src/views/package/edit.vue ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _edit_vue_vue_type_template_id_7ee20a86_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./edit.vue?vue&type=template&id=7ee20a86&scoped=true& */ "./resources/js/src/views/package/edit.vue?vue&type=template&id=7ee20a86&scoped=true&");
/* harmony import */ var _edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edit.vue?vue&type=script&lang=js& */ "./resources/js/src/views/package/edit.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _edit_vue_vue_type_style_index_0_id_7ee20a86_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./edit.vue?vue&type=style&index=0&id=7ee20a86&scoped=true&lang=css& */ "./resources/js/src/views/package/edit.vue?vue&type=style&index=0&id=7ee20a86&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _edit_vue_vue_type_template_id_7ee20a86_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _edit_vue_vue_type_template_id_7ee20a86_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "7ee20a86",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/package/edit.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/package/edit.vue?vue&type=script&lang=js&":
/*!**************************************************************************!*\
  !*** ./resources/js/src/views/package/edit.vue?vue&type=script&lang=js& ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./edit.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/package/edit.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/package/edit.vue?vue&type=style&index=0&id=7ee20a86&scoped=true&lang=css&":
/*!**********************************************************************************************************!*\
  !*** ./resources/js/src/views/package/edit.vue?vue&type=style&index=0&id=7ee20a86&scoped=true&lang=css& ***!
  \**********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_edit_vue_vue_type_style_index_0_id_7ee20a86_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/style-loader!../../../../../node_modules/css-loader??ref--7-1!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../node_modules/vue-loader/lib??vue-loader-options!./edit.vue?vue&type=style&index=0&id=7ee20a86&scoped=true&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/package/edit.vue?vue&type=style&index=0&id=7ee20a86&scoped=true&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_edit_vue_vue_type_style_index_0_id_7ee20a86_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_edit_vue_vue_type_style_index_0_id_7ee20a86_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_edit_vue_vue_type_style_index_0_id_7ee20a86_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_edit_vue_vue_type_style_index_0_id_7ee20a86_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./resources/js/src/views/package/edit.vue?vue&type=template&id=7ee20a86&scoped=true&":
/*!********************************************************************************************!*\
  !*** ./resources/js/src/views/package/edit.vue?vue&type=template&id=7ee20a86&scoped=true& ***!
  \********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_edit_vue_vue_type_template_id_7ee20a86_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./edit.vue?vue&type=template&id=7ee20a86&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/package/edit.vue?vue&type=template&id=7ee20a86&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_edit_vue_vue_type_template_id_7ee20a86_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_edit_vue_vue_type_template_id_7ee20a86_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);