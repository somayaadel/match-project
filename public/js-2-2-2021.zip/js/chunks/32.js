(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[32],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridFlexAlignment.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui-elements/grid/vuesax/GridFlexAlignment.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _flex_alignment_FlexAlignmentTop_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./flex-alignment/FlexAlignmentTop.vue */ "./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentTop.vue");
/* harmony import */ var _flex_alignment_FlexAlignmentCenter_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./flex-alignment/FlexAlignmentCenter.vue */ "./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentCenter.vue");
/* harmony import */ var _flex_alignment_FlexAlignmentBottom_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./flex-alignment/FlexAlignmentBottom.vue */ "./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentBottom.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    FlexAlignmentTop: _flex_alignment_FlexAlignmentTop_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    FlexAlignmentCenter: _flex_alignment_FlexAlignmentCenter_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    FlexAlignmentBottom: _flex_alignment_FlexAlignmentBottom_vue__WEBPACK_IMPORTED_MODULE_2__["default"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridOverview.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui-elements/grid/vuesax/GridOverview.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      list: ["Establish a set of column in the horizontal space defined by row (abbreviated col)", "Your content elements should be placed directly in the col, and only col should be placed directly in row", "The column grid system is a value from 1-12 to represent its range spans. For example, three columns of equal width can be created by .col-4 (33.3%)", "If the sum of col spans in a row are more than 12, then the overflowing col as a whole will start a new line arrangement"]
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridResponsiveLayout.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui-elements/grid/vuesax/GridResponsiveLayout.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      list: ["<code>vs-lg</code> : is for large devices such as desktops or laptops (large)", "<code>vs-sm</code> : is for medium devices such as laptops or tablets", "<code>vs-xs</code> : is for small devices such as tablets (small) and phones"]
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridVuesax.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui-elements/grid/vuesax/GridVuesax.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _GridOverview_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./GridOverview.vue */ "./resources/js/src/views/ui-elements/grid/vuesax/GridOverview.vue");
/* harmony import */ var _GridDesignConcept_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./GridDesignConcept.vue */ "./resources/js/src/views/ui-elements/grid/vuesax/GridDesignConcept.vue");
/* harmony import */ var _GridColumnOffset_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./GridColumnOffset.vue */ "./resources/js/src/views/ui-elements/grid/vuesax/GridColumnOffset.vue");
/* harmony import */ var _GridFlexLayout_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./GridFlexLayout.vue */ "./resources/js/src/views/ui-elements/grid/vuesax/GridFlexLayout.vue");
/* harmony import */ var _GridFlexAlignment_vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./GridFlexAlignment.vue */ "./resources/js/src/views/ui-elements/grid/vuesax/GridFlexAlignment.vue");
/* harmony import */ var _GridFlexOrder_vue__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./GridFlexOrder.vue */ "./resources/js/src/views/ui-elements/grid/vuesax/GridFlexOrder.vue");
/* harmony import */ var _GridResponsiveLayout_vue__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./GridResponsiveLayout.vue */ "./resources/js/src/views/ui-elements/grid/vuesax/GridResponsiveLayout.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//







/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    GridOverview: _GridOverview_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    GridDesignConcept: _GridDesignConcept_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    GridColumnOffset: _GridColumnOffset_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    GridFlexLayout: _GridFlexLayout_vue__WEBPACK_IMPORTED_MODULE_3__["default"],
    GridFlexAlignment: _GridFlexAlignment_vue__WEBPACK_IMPORTED_MODULE_4__["default"],
    GridFlexOrder: _GridFlexOrder_vue__WEBPACK_IMPORTED_MODULE_5__["default"],
    GridResponsiveLayout: _GridResponsiveLayout_vue__WEBPACK_IMPORTED_MODULE_6__["default"]
  }
});

/***/ }),

/***/ "./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridVuesax.vue?vue&type=style&index=0&lang=scss&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--8-2!./node_modules/sass-loader/dist/cjs.js??ref--8-3!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui-elements/grid/vuesax/GridVuesax.vue?vue&type=style&index=0&lang=scss& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "/*=========================================================================================\n    File Name: grid.scss\n    Description: Grid page styles\n    ----------------------------------------------------------------------------------------\n    Item Name: Vuexy - Vuejs, HTML & Laravel Admin Dashboard Template\n      Author: Pixinvent\n    Author URL: http://www.themeforest.net/user/pixinvent\n==========================================================================================*/\n[dir] .grid-demo__layout-container {\n  margin-top: 1.25rem;\n}\n[dir] .grid-demo__layout-container .vs-row {\n  border-top: 1px solid #808080;\n}\n[dir] .grid-demo__layout-container .vs-row:last-child {\n  border-bottom: 1px solid #808080;\n}\n[dir] .grid-demo__layout-container .vs-row:not(:last-of-type) {\n  border-bottom: 0px solid #808080;\n}\n[dir] .grid-demo__layout-container .vs-row .vs-col {\n  padding: 0.5rem;\n  background-color: #eceaff;\n}\n[dir=ltr] .grid-demo__layout-container .vs-row .vs-col {\n  border-left: 1px solid #808080;\n}\n[dir=rtl] .grid-demo__layout-container .vs-row .vs-col {\n  border-right: 1px solid #808080;\n}\n[dir=ltr] .grid-demo__layout-container .vs-row .vs-col:last-of-type {\n  border-right: 1px solid #808080;\n}\n[dir=rtl] .grid-demo__layout-container .vs-row .vs-col:last-of-type {\n  border-left: 1px solid #808080;\n}\n.grid-demo__layout-container--block {\n  display: flex;\n  min-height: 75px;\n}\n[dir] .grid-demo__layout-container--block {\n  background: #f1f1f1;\n}\n[dir] .grid-demo__layout-container--block .vs-row {\n  border: 0px solid #808080;\n}\n[dir] .grid-demo__layout-container--block .vs-col {\n  border: 1px solid #808080;\n}\n[dir=ltr] .grid-demo__layout-container--block .vs-col:not(:last-of-type) {\n  border-right: 0;\n}\n[dir=rtl] .grid-demo__layout-container--block .vs-col:not(:last-of-type) {\n  border-left: 0;\n}", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridVuesax.vue?vue&type=style&index=0&lang=scss&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--8-2!./node_modules/sass-loader/dist/cjs.js??ref--8-3!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui-elements/grid/vuesax/GridVuesax.vue?vue&type=style&index=0&lang=scss& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../../../node_modules/css-loader!../../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../node_modules/postcss-loader/src??ref--8-2!../../../../../../../node_modules/sass-loader/dist/cjs.js??ref--8-3!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./GridVuesax.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridVuesax.vue?vue&type=style&index=0&lang=scss&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridColumnOffset.vue?vue&type=template&id=6af78cfa&":
/*!******************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui-elements/grid/vuesax/GridColumnOffset.vue?vue&type=template&id=6af78cfa& ***!
  \******************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Column offset", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v(
          "To give a distance with respect to the left we have the directive vs-offset that with the same measures 1-12 we add the space specified a serious example "
        ),
        _c("code", [_vm._v("12 = 100%")]),
        _vm._v(", "),
        _c("code", [_vm._v("6 = 50%")]),
        _vm._v(", "),
        _c("code", [_vm._v("4 = 25%")])
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "grid-demo__layout-container" },
        [
          _c(
            "vs-row",
            { attrs: { "vs-w": "12" } },
            [
              _c(
                "vs-col",
                {
                  staticClass: "sm:p-2 p-4",
                  attrs: {
                    "vs-offset": "5",
                    "vs-type": "flex",
                    "vs-justify": "center",
                    "vs-align": "center",
                    "vs-w": "6"
                  }
                },
                [
                  _c("span", { staticClass: "sm:inline hidden" }, [
                    _vm._v("offset - 6")
                  ])
                ]
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "vs-row",
            [
              _c(
                "vs-col",
                {
                  staticClass: "sm:p-2 p-4",
                  attrs: {
                    "vs-offset": "0",
                    "vs-type": "flex",
                    "vs-justify": "center",
                    "vs-align": "center",
                    "vs-w": "2"
                  }
                },
                [
                  _c("span", { staticClass: "sm:inline hidden" }, [
                    _vm._v("offset - 2")
                  ])
                ]
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "vs-row",
            [
              _c(
                "vs-col",
                {
                  staticClass: "sm:p-2 p-4",
                  attrs: {
                    "vs-offset": "2",
                    "vs-type": "flex",
                    "vs-justify": "center",
                    "vs-align": "center",
                    "vs-w": "8"
                  }
                },
                [
                  _c("span", { staticClass: "sm:inline hidden" }, [
                    _vm._v("offset - 8")
                  ])
                ]
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "vs-row",
            [
              _c(
                "vs-col",
                {
                  staticClass: "sm:p-2 p-4",
                  attrs: {
                    "vs-offset": "10",
                    "vs-type": "flex",
                    "vs-justify": "center",
                    "vs-align": "center",
                    "vs-w": "2"
                  }
                },
                [
                  _c("span", { staticClass: "sm:inline hidden" }, [
                    _vm._v("offset - 7")
                  ])
                ]
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "vs-row",
            [
              _c(
                "vs-col",
                {
                  staticClass: "sm:p-2 p-4",
                  attrs: {
                    "vs-offset": "4",
                    "vs-type": "flex",
                    "vs-justify": "center",
                    "vs-align": "center",
                    "vs-w": "4"
                  }
                },
                [
                  _c("span", { staticClass: "sm:inline hidden" }, [
                    _vm._v("offset - 4")
                  ])
                ]
              )
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<vs-row vs-w="12">\n  <vs-col vs-offset="5" vs-type="flex" vs-justify="center" vs-align="center" vs-w="6">\n    offset - 6\n  </vs-col>\n</vs-row>\n\n<vs-row>\n  <vs-col vs-offset="0" v-tooltip="\'col - 2\'" vs-type="flex" vs-justify="center" vs-align="center" vs-w="2">\n    offset - 2\n  </vs-col>\n</vs-row>\n\n<vs-row>\n  <vs-col vs-offset="2" v-tooltip="\'col - 8\'" vs-type="flex" vs-justify="center" vs-align="center" vs-w="8">\n    offset - 8\n  </vs-col>\n</vs-row>\n\n<vs-row>\n  <vs-col vs-offset="10" v-tooltip="\'col - 1\'" vs-type="flex" vs-justify="center" vs-align="center" vs-w="2">\n    offset - 7\n  </vs-col>\n</vs-row>\n\n<vs-row>\n  <vs-col vs-offset="4" v-tooltip="\'col - 4\'" vs-type="flex" vs-justify="center" vs-align="center" vs-w="4">\n    offset - 4\n  </vs-col>\n</vs-row>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridDesignConcept.vue?vue&type=template&id=794d2c29&":
/*!*******************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui-elements/grid/vuesax/GridDesignConcept.vue?vue&type=template&id=794d2c29& ***!
  \*******************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Design Concept", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v("With the directive "),
        _c("code", [_vm._v("vs-w")]),
        _vm._v(" define the width of the column ("),
        _c("code", [_vm._v("vs-col")]),
        _vm._v(") its value is "),
        _c("strong", [_vm._v("1-12")]),
        _vm._v(" an example of sizes would be: "),
        _c("strong", [_vm._v("12 = 100%, 6 = 50%, 4 = 25%")])
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "grid-demo__layout-container" },
        [
          _c(
            "vs-row",
            [
              _c(
                "vs-col",
                {
                  staticClass: "p-4 sm:p-2",
                  attrs: {
                    "vs-type": "flex",
                    "vs-justify": "center",
                    "vs-align": "center",
                    "vs-w": "12"
                  }
                },
                [
                  _c("span", { staticClass: "sm:inline hidden" }, [
                    _vm._v("100%")
                  ])
                ]
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "vs-row",
            _vm._l(2, function(col, index) {
              return _c(
                "vs-col",
                {
                  key: index,
                  staticClass: "p-4 sm:p-2",
                  attrs: {
                    "vs-type": "flex",
                    "vs-justify": "center",
                    "vs-align": "center",
                    "vs-w": "6"
                  }
                },
                [
                  _c("span", { staticClass: "sm:inline hidden" }, [
                    _vm._v("50%")
                  ])
                ]
              )
            }),
            1
          ),
          _vm._v(" "),
          _c(
            "vs-row",
            _vm._l(3, function(col, index) {
              return _c(
                "vs-col",
                {
                  key: index,
                  staticClass: "p-4 sm:p-2",
                  attrs: {
                    "vs-type": "flex",
                    "vs-justify": "center",
                    "vs-align": "center",
                    "vs-w": "4"
                  }
                },
                [
                  _c("span", { staticClass: "sm:inline hidden" }, [
                    _vm._v("33.3%")
                  ])
                ]
              )
            }),
            1
          ),
          _vm._v(" "),
          _c(
            "vs-row",
            _vm._l(4, function(col, index) {
              return _c(
                "vs-col",
                {
                  key: index,
                  staticClass: "p-4 sm:p-2",
                  attrs: {
                    "vs-type": "flex",
                    "vs-justify": "center",
                    "vs-align": "center",
                    "vs-w": "3"
                  }
                },
                [
                  _c("span", { staticClass: "sm:inline hidden" }, [
                    _vm._v("25%")
                  ])
                ]
              )
            }),
            1
          ),
          _vm._v(" "),
          _c(
            "vs-row",
            _vm._l(6, function(col, index) {
              return _c(
                "vs-col",
                {
                  key: index,
                  staticClass: "p-4 sm:p-2",
                  attrs: {
                    "vs-type": "flex",
                    "vs-justify": "center",
                    "vs-align": "center",
                    "vs-w": "2"
                  }
                },
                [
                  _c("span", { staticClass: "sm:inline hidden" }, [
                    _vm._v("16.6%")
                  ])
                ]
              )
            }),
            1
          ),
          _vm._v(" "),
          _c(
            "vs-row",
            _vm._l(12, function(col, index) {
              return _c(
                "vs-col",
                {
                  key: index,
                  staticClass: "p-4 sm:p-2",
                  attrs: {
                    "vs-type": "flex",
                    "vs-justify": "center",
                    "vs-align": "center",
                    "vs-w": "1"
                  }
                },
                [
                  _c("span", { staticClass: "sm:inline hidden" }, [
                    _vm._v("8.3%")
                  ])
                ]
              )
            }),
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<vs-row>\n  <vs-col vs-type="flex" vs-justify="center" vs-align="center" vs-w="12">\n    100%\n  </vs-col>\n</vs-row>\n\n<vs-row>\n  <vs-col :key="index" v-for="col,index in 2" vs-type="flex" vs-justify="center" vs-align="center" vs-w="6">\n    50%\n  </vs-col>\n</vs-row>\n\n<vs-row>\n  <vs-col :key="index" v-for="col,index in 3" v-tooltip="\'col - 4\'" vs-type="flex" vs-justify="center" vs-align="center" vs-w="4">\n    33.3%\n  </vs-col>\n</vs-row>\n\n<vs-row>\n  <vs-col :key="index" v-for="col,index in 4" v-tooltip="\'col - 3\'" vs-type="flex" vs-justify="center" vs-align="center" vs-w="3">\n    25%\n  </vs-col>\n</vs-row>\n\n<vs-row>\n  <vs-col :key="index" v-for="col,index in 6" v-tooltip="\'col - 2\'" vs-type="flex" vs-justify="center" vs-align="center" vs-w="2">\n    16.6%\n  </vs-col>\n</vs-row>\n\n<vs-row>\n  <vs-col :key="index" v-for="col,index in 12" v-tooltip="\'col - 1\'" vs-type="flex" vs-justify="center" vs-align="center" vs-w="1">\n    8.3%\n  </vs-col>\n</vs-row>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridFlexAlignment.vue?vue&type=template&id=b860716e&":
/*!*******************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui-elements/grid/vuesax/GridFlexAlignment.vue?vue&type=template&id=b860716e& ***!
  \*******************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("vx-card", { attrs: { title: "Flex alignment" } }, [
    _c("p", [
      _vm._v("To align the elements vertically we have the directive "),
      _c("code", [_vm._v("vs-align")]),
      _vm._v(" that as parameters the same known values of css: "),
      _c("code", [_vm._v("center")]),
      _vm._v(", "),
      _c("code", [_vm._v("flex-end")]),
      _vm._v(", "),
      _c("code", [_vm._v("flex-start")]),
      _vm._v(".")
    ]),
    _vm._v(" "),
    _c(
      "div",
      { staticClass: "mt-5" },
      [
        _c("flex-alignment-top"),
        _vm._v(" "),
        _c("flex-alignment-center"),
        _vm._v(" "),
        _c("flex-alignment-bottom")
      ],
      1
    )
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridFlexLayout.vue?vue&type=template&id=1740ff34&":
/*!****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui-elements/grid/vuesax/GridFlexLayout.vue?vue&type=template&id=1740ff34& ***!
  \****************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Flex layout", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v("If we need to align the elements horizontally, use the "),
        _c("code", [_vm._v("vs-justify")]),
        _vm._v(" directive that uses CSS attributes as parameters: "),
        _c("code", [_vm._v("flex-start")]),
        _vm._v(", "),
        _c("code", [_vm._v("center")]),
        _vm._v(", "),
        _c("code", [_vm._v("flex-end")]),
        _vm._v(", "),
        _c("code", [_vm._v("space-around")]),
        _vm._v(", "),
        _c("code", [_vm._v("space-between")])
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "grid-demo__layout-container" },
        [
          _c(
            "vs-row",
            { attrs: { "vs-w": "12" } },
            _vm._l(3, function(col, index) {
              return _c(
                "vs-col",
                {
                  key: index,
                  staticClass: "sm:p-0 p-4 text-center",
                  attrs: {
                    "vs-type": "flex",
                    "vs-justify": "center",
                    "vs-align": "center",
                    "vs-w": "2"
                  }
                },
                [
                  _c("span", { staticClass: "sm:inline hidden" }, [
                    _vm._v("default")
                  ])
                ]
              )
            }),
            1
          ),
          _vm._v(" "),
          _c(
            "vs-row",
            { attrs: { "vs-type": "flex", "vs-justify": "center" } },
            _vm._l(3, function(col, index) {
              return _c(
                "vs-col",
                {
                  key: index,
                  staticClass: "sm:p-0 p-4 text-center",
                  attrs: {
                    "vs-type": "flex",
                    "vs-justify": "center",
                    "vs-align": "center",
                    "vs-w": "2"
                  }
                },
                [
                  _c("span", { staticClass: "sm:inline hidden" }, [
                    _vm._v("center")
                  ])
                ]
              )
            }),
            1
          ),
          _vm._v(" "),
          _c(
            "vs-row",
            { attrs: { "vs-type": "flex", "vs-justify": "flex-end" } },
            _vm._l(3, function(col, index) {
              return _c(
                "vs-col",
                {
                  key: index,
                  staticClass: "sm:p-0 p-4 text-center",
                  attrs: {
                    "vs-type": "flex",
                    "vs-justify": "center",
                    "vs-align": "center",
                    "vs-w": "2"
                  }
                },
                [
                  _c("span", { staticClass: "sm:inline hidden" }, [
                    _vm._v("flex-end")
                  ])
                ]
              )
            }),
            1
          ),
          _vm._v(" "),
          _c(
            "vs-row",
            { attrs: { "vs-type": "flex", "vs-justify": "space-around" } },
            _vm._l(3, function(col, index) {
              return _c(
                "vs-col",
                {
                  key: index,
                  staticClass: "sm:p-0 p-4 text-center",
                  attrs: {
                    "vs-type": "flex",
                    "vs-justify": "center",
                    "vs-align": "center",
                    "vs-w": "2"
                  }
                },
                [
                  _c("span", { staticClass: "sm:inline hidden" }, [
                    _vm._v("space-around")
                  ])
                ]
              )
            }),
            1
          ),
          _vm._v(" "),
          _c(
            "vs-row",
            { attrs: { "vs-type": "flex", "vs-justify": "space-between" } },
            _vm._l(3, function(col, index) {
              return _c(
                "vs-col",
                {
                  key: index,
                  staticClass: "sm:p-0 p-4 text-center",
                  attrs: {
                    "vs-type": "flex",
                    "vs-justify": "center",
                    "vs-align": "center",
                    "vs-w": "2"
                  }
                },
                [
                  _c("span", { staticClass: "sm:inline hidden" }, [
                    _vm._v("space-between")
                  ])
                ]
              )
            }),
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<vs-row vs-w="12">\n  <vs-col :key="index" v-for="col,index in 3" vs-type="flex" vs-justify="center" vs-align="center" vs-w="2">\n    default\n  </vs-col>\n</vs-row>\n\n<vs-row vs-type="flex" vs-justify="center">\n  <vs-col :key="index" v-for="col,index in 3" vs-type="flex" vs-justify="center" vs-align="center" vs-w="2">\n    center\n  </vs-col>\n</vs-row>\n\n<vs-row vs-type="flex" vs-justify="flex-end">\n  <vs-col :key="index" v-for="col,index in 3" vs-type="flex" vs-justify="center" vs-align="center" vs-w="2">\n    flex-end\n  </vs-col>\n</vs-row>\n\n\n<vs-row vs-type="flex" vs-justify="space-around">\n  <vs-col :key="index" v-for="col,index in 3" vs-type="flex" vs-justify="center" vs-align="center" vs-w="2">\n    space-around\n  </vs-col>\n</vs-row>\n\n<vs-row vs-type="flex" vs-justify="space-between">\n  <vs-col :key="index" v-for="col,index in 3" vs-type="flex" vs-justify="center" vs-align="center" vs-w="2">\n    space-between\n  </vs-col>\n</vs-row>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridFlexOrder.vue?vue&type=template&id=6cd15634&":
/*!***************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui-elements/grid/vuesax/GridFlexOrder.vue?vue&type=template&id=6cd15634& ***!
  \***************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Flex Order", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v(
          "In some cases, we want to order the elements to our liking. To do this, use the directive "
        ),
        _c("code", [_vm._v("vs-order")]),
        _vm._v(
          " that has a parameter you just have to pass the number in which we want to order the "
        ),
        _c("code", [_vm._v("vs-col")]),
        _vm._v(" with respect to his brothers "),
        _c("code", [_vm._v("vs-col")])
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "grid-demo__layout-container" },
        [
          _c(
            "vs-row",
            { attrs: { "vs-type": "flex" } },
            [
              _c(
                "vs-col",
                {
                  staticClass: "sm:p-2 p-4",
                  attrs: {
                    "vs-order": "3",
                    "vs-type": "flex",
                    "vs-justify": "center",
                    "vs-align": "center",
                    "vs-w": "3"
                  }
                },
                [
                  _c("span", { staticClass: "sm:inline hidden" }, [
                    _vm._v("1 / order ")
                  ]),
                  _c("span", [_vm._v("3")])
                ]
              ),
              _vm._v(" "),
              _c(
                "vs-col",
                {
                  staticClass: "sm:p-2 p-4",
                  attrs: {
                    "vs-order": "1",
                    "vs-type": "flex",
                    "vs-justify": "center",
                    "vs-align": "center",
                    "vs-w": "3"
                  }
                },
                [
                  _c("span", { staticClass: "sm:inline hidden" }, [
                    _vm._v("2 / order ")
                  ]),
                  _c("span", [_vm._v("1")])
                ]
              ),
              _vm._v(" "),
              _c(
                "vs-col",
                {
                  staticClass: "sm:p-2 p-4",
                  attrs: {
                    "vs-order": "4",
                    "vs-type": "flex",
                    "vs-justify": "center",
                    "vs-align": "center",
                    "vs-w": "3"
                  }
                },
                [
                  _c("span", { staticClass: "sm:inline hidden" }, [
                    _vm._v("3 / order ")
                  ]),
                  _c("span", [_vm._v("4")])
                ]
              ),
              _vm._v(" "),
              _c(
                "vs-col",
                {
                  staticClass: "sm:p-2 p-4",
                  attrs: {
                    "vs-order": "2",
                    "vs-type": "flex",
                    "vs-justify": "center",
                    "vs-align": "center",
                    "vs-w": "3"
                  }
                },
                [
                  _c("span", { staticClass: "sm:inline hidden" }, [
                    _vm._v("4 / order ")
                  ]),
                  _c("span", [_vm._v("2")])
                ]
              )
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<vs-row vs-type="flex">\n  <vs-col\n    vs-order="3"\n    vs-type="flex" vs-justify="center" vs-align="center" vs-w="3">\n      1 / order 3\n  </vs-col>\n  <vs-col\n    vs-order="1"\n    vs-type="flex" vs-justify="center" vs-align="center" vs-w="3">\n      2 / order 1\n  </vs-col>\n  <vs-col\n    vs-order="4"\n    vs-type="flex" vs-justify="center" vs-align="center" vs-w="3">\n      3 / order 4\n  </vs-col>\n  <vs-col\n    vs-order="2"\n    vs-type="flex" vs-justify="center" vs-align="center" vs-w="3">\n      4 / order 2\n  </vs-col>\n</vs-row>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridOverview.vue?vue&type=template&id=379a692c&":
/*!**************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui-elements/grid/vuesax/GridOverview.vue?vue&type=template&id=379a692c& ***!
  \**************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Overview" } },
    [
      _c("p", [_vm._v("Following is a brief look at how it works:")]),
      _vm._v(" "),
      _c("vx-list", { staticClass: "mt-5", attrs: { list: _vm.list } })
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridResponsiveLayout.vue?vue&type=template&id=0b3fbf22&":
/*!**********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui-elements/grid/vuesax/GridResponsiveLayout.vue?vue&type=template&id=0b3fbf22& ***!
  \**********************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Responsive layout", "code-toggler": "" } },
    [
      _c("p", { staticClass: "mb-5" }, [
        _vm._v(
          "There are some measures that can only be added in a specific size of the device, the directives are:"
        )
      ]),
      _vm._v(" "),
      _c("vx-list", { attrs: { list: _vm.list } }),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "grid-demo__layout-container" },
        [
          _c(
            "vs-row",
            { attrs: { "vs-w": "12" } },
            [
              _c(
                "vs-col",
                {
                  attrs: {
                    "vs-type": "flex",
                    "vs-justify": "center",
                    "vs-align": "center",
                    "vs-lg": "2",
                    "vs-sm": "4",
                    "vs-xs": "12"
                  }
                },
                [_vm._v('\n                    vs-lg="2" ')]
              ),
              _vm._v(" "),
              _c(
                "vs-col",
                {
                  attrs: {
                    "vs-type": "flex",
                    "vs-justify": "center",
                    "vs-align": "center",
                    "vs-lg": "8",
                    "vs-sm": "4",
                    "vs-xs": "12"
                  }
                },
                [_vm._v('\n                    vs-lg="8" ')]
              ),
              _vm._v(" "),
              _c(
                "vs-col",
                {
                  attrs: {
                    "vs-type": "flex",
                    "vs-justify": "center",
                    "vs-align": "center",
                    "vs-lg": "2",
                    "vs-sm": "4",
                    "vs-xs": "12"
                  }
                },
                [_vm._v('\n                    vs-lg="2" ')]
              )
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n\n<vs-row vs-w="12">\n  <vs-col vs-type="flex" vs-justify="center" vs-align="center" vs-lg="2" vs-sm="4" vs-xs="12" >\n    vs-lg="2" <!-- vs-sm="4" vs-xs="12" -->\n  </vs-col>\n  <vs-col vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="4" vs-xs="12">\n    vs-lg="8" <!-- vs-sm="4" vs-xs="12" -->\n  </vs-col>\n  <vs-col vs-type="flex" vs-justify="center" vs-align="center" vs-lg="2" vs-sm="4" vs-xs="12">\n    vs-lg="2" <!-- vs-sm="4" vs-xs="12" -->\n  </vs-col>\n</vs-row>\n\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridVuesax.vue?vue&type=template&id=99cea156&":
/*!************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui-elements/grid/vuesax/GridVuesax.vue?vue&type=template&id=99cea156& ***!
  \************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { attrs: { id: "vuexy-grid-demo" } },
    [
      _c("grid-overview"),
      _vm._v(" "),
      _c("grid-design-concept"),
      _vm._v(" "),
      _c("grid-column-offset"),
      _vm._v(" "),
      _c("grid-flex-layout"),
      _vm._v(" "),
      _c("grid-flex-alignment"),
      _vm._v(" "),
      _c("grid-flex-order"),
      _vm._v(" "),
      _c("grid-responsive-layout")
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentBottom.vue?vue&type=template&id=712b9680&":
/*!************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentBottom.vue?vue&type=template&id=712b9680& ***!
  \************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    {
      attrs: {
        title: "Align Bottom",
        "code-toggler": "",
        "no-shadow": "",
        "card-border": ""
      }
    },
    [
      _c(
        "div",
        { staticClass: "grid-demo__layout-container--block" },
        [
          _c(
            "vs-row",
            {
              attrs: {
                "vs-align": "flex-end",
                "vs-type": "flex",
                "vs-justify": "center",
                "vs-w": "12"
              }
            },
            _vm._l(4, function(col, index) {
              return _c(
                "vs-col",
                {
                  key: index,
                  staticClass: "sm:p-2 p-4",
                  attrs: {
                    "vs-type": "flex",
                    "vs-justify": "center",
                    "vs-align": "center",
                    "vs-w": "2"
                  }
                },
                [
                  _c("span", { staticClass: "sm:inline hidden" }, [
                    _vm._v("col - 3")
                  ])
                ]
              )
            }),
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<div class="grid-layout-container alignment-block">\n  <vs-row\n    vs-align="flex-end"\n    vs-type="flex" vs-justify="center" vs-w="12">\n    <vs-col :key="index" v-for="col,index in 4" vs-type="flex" vs-justify="center" vs-align="center" vs-w="2">\n      col - 3\n    </vs-col>\n  </vs-row>\n</div>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentCenter.vue?vue&type=template&id=70f641ea&":
/*!************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentCenter.vue?vue&type=template&id=70f641ea& ***!
  \************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    {
      attrs: {
        title: "Align Center",
        "code-toggler": "",
        "no-shadow": "",
        "card-border": ""
      }
    },
    [
      _c(
        "div",
        { staticClass: "grid-demo__layout-container--block" },
        [
          _c(
            "vs-row",
            {
              attrs: {
                "vs-align": "center",
                "vs-type": "flex",
                "vs-justify": "center",
                "vs-w": "12"
              }
            },
            _vm._l(4, function(col, index) {
              return _c(
                "vs-col",
                {
                  key: index,
                  staticClass: "sm:p-2 p-4",
                  attrs: {
                    "vs-type": "flex",
                    "vs-justify": "center",
                    "vs-align": "center",
                    "vs-w": "2"
                  }
                },
                [
                  _c("span", { staticClass: "sm:inline hidden" }, [
                    _vm._v("col - 3")
                  ])
                ]
              )
            }),
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<div class="grid-layout-container alignment-block">\n  <vs-row\n    vs-align="center"\n    vs-type="flex" vs-justify="center" vs-w="12">\n    <vs-col :key="index" v-for="col,index in 4" vs-type="flex" vs-justify="center" vs-align="center" vs-w="2">\n      col - 3\n    </vs-col>\n  </vs-row>\n</div>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentTop.vue?vue&type=template&id=3cb80510&":
/*!*********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentTop.vue?vue&type=template&id=3cb80510& ***!
  \*********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    {
      attrs: {
        title: "Align Top",
        "code-toggler": "",
        "no-shadow": "",
        "card-border": ""
      }
    },
    [
      _c(
        "div",
        { staticClass: "grid-demo__layout-container--block" },
        [
          _c(
            "vs-row",
            {
              attrs: {
                "vs-align": "flex-start",
                "vs-type": "flex",
                "vs-justify": "center",
                "vs-w": "12"
              }
            },
            _vm._l(4, function(col, index) {
              return _c(
                "vs-col",
                {
                  key: index,
                  staticClass: "sm:p-2 p-4",
                  attrs: {
                    "vs-type": "flex",
                    "vs-justify": "center",
                    "vs-align": "center",
                    "vs-w": "2"
                  }
                },
                [
                  _c("span", { staticClass: "sm:inline hidden" }, [
                    _vm._v("col - 3")
                  ])
                ]
              )
            }),
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<div class="grid-layout-container alignment-block">\n  <vs-row\n    vs-align="flex-start"\n    vs-type="flex" vs-justify="center" vs-w="12">\n    <vs-col :key="index" v-for="col,index in 4" vs-type="flex" vs-justify="center" vs-align="center" vs-w="2">\n      col - 3\n    </vs-col>\n  </vs-row>\n</div>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/GridColumnOffset.vue":
/*!*****************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/GridColumnOffset.vue ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _GridColumnOffset_vue_vue_type_template_id_6af78cfa___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./GridColumnOffset.vue?vue&type=template&id=6af78cfa& */ "./resources/js/src/views/ui-elements/grid/vuesax/GridColumnOffset.vue?vue&type=template&id=6af78cfa&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _GridColumnOffset_vue_vue_type_template_id_6af78cfa___WEBPACK_IMPORTED_MODULE_0__["render"],
  _GridColumnOffset_vue_vue_type_template_id_6af78cfa___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/ui-elements/grid/vuesax/GridColumnOffset.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/GridColumnOffset.vue?vue&type=template&id=6af78cfa&":
/*!************************************************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/GridColumnOffset.vue?vue&type=template&id=6af78cfa& ***!
  \************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GridColumnOffset_vue_vue_type_template_id_6af78cfa___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./GridColumnOffset.vue?vue&type=template&id=6af78cfa& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridColumnOffset.vue?vue&type=template&id=6af78cfa&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GridColumnOffset_vue_vue_type_template_id_6af78cfa___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GridColumnOffset_vue_vue_type_template_id_6af78cfa___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/GridDesignConcept.vue":
/*!******************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/GridDesignConcept.vue ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _GridDesignConcept_vue_vue_type_template_id_794d2c29___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./GridDesignConcept.vue?vue&type=template&id=794d2c29& */ "./resources/js/src/views/ui-elements/grid/vuesax/GridDesignConcept.vue?vue&type=template&id=794d2c29&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _GridDesignConcept_vue_vue_type_template_id_794d2c29___WEBPACK_IMPORTED_MODULE_0__["render"],
  _GridDesignConcept_vue_vue_type_template_id_794d2c29___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/ui-elements/grid/vuesax/GridDesignConcept.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/GridDesignConcept.vue?vue&type=template&id=794d2c29&":
/*!*************************************************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/GridDesignConcept.vue?vue&type=template&id=794d2c29& ***!
  \*************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GridDesignConcept_vue_vue_type_template_id_794d2c29___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./GridDesignConcept.vue?vue&type=template&id=794d2c29& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridDesignConcept.vue?vue&type=template&id=794d2c29&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GridDesignConcept_vue_vue_type_template_id_794d2c29___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GridDesignConcept_vue_vue_type_template_id_794d2c29___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/GridFlexAlignment.vue":
/*!******************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/GridFlexAlignment.vue ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _GridFlexAlignment_vue_vue_type_template_id_b860716e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./GridFlexAlignment.vue?vue&type=template&id=b860716e& */ "./resources/js/src/views/ui-elements/grid/vuesax/GridFlexAlignment.vue?vue&type=template&id=b860716e&");
/* harmony import */ var _GridFlexAlignment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./GridFlexAlignment.vue?vue&type=script&lang=js& */ "./resources/js/src/views/ui-elements/grid/vuesax/GridFlexAlignment.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _GridFlexAlignment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _GridFlexAlignment_vue_vue_type_template_id_b860716e___WEBPACK_IMPORTED_MODULE_0__["render"],
  _GridFlexAlignment_vue_vue_type_template_id_b860716e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/ui-elements/grid/vuesax/GridFlexAlignment.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/GridFlexAlignment.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/GridFlexAlignment.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_GridFlexAlignment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./GridFlexAlignment.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridFlexAlignment.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_GridFlexAlignment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/GridFlexAlignment.vue?vue&type=template&id=b860716e&":
/*!*************************************************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/GridFlexAlignment.vue?vue&type=template&id=b860716e& ***!
  \*************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GridFlexAlignment_vue_vue_type_template_id_b860716e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./GridFlexAlignment.vue?vue&type=template&id=b860716e& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridFlexAlignment.vue?vue&type=template&id=b860716e&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GridFlexAlignment_vue_vue_type_template_id_b860716e___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GridFlexAlignment_vue_vue_type_template_id_b860716e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/GridFlexLayout.vue":
/*!***************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/GridFlexLayout.vue ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _GridFlexLayout_vue_vue_type_template_id_1740ff34___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./GridFlexLayout.vue?vue&type=template&id=1740ff34& */ "./resources/js/src/views/ui-elements/grid/vuesax/GridFlexLayout.vue?vue&type=template&id=1740ff34&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _GridFlexLayout_vue_vue_type_template_id_1740ff34___WEBPACK_IMPORTED_MODULE_0__["render"],
  _GridFlexLayout_vue_vue_type_template_id_1740ff34___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/ui-elements/grid/vuesax/GridFlexLayout.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/GridFlexLayout.vue?vue&type=template&id=1740ff34&":
/*!**********************************************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/GridFlexLayout.vue?vue&type=template&id=1740ff34& ***!
  \**********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GridFlexLayout_vue_vue_type_template_id_1740ff34___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./GridFlexLayout.vue?vue&type=template&id=1740ff34& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridFlexLayout.vue?vue&type=template&id=1740ff34&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GridFlexLayout_vue_vue_type_template_id_1740ff34___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GridFlexLayout_vue_vue_type_template_id_1740ff34___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/GridFlexOrder.vue":
/*!**************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/GridFlexOrder.vue ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _GridFlexOrder_vue_vue_type_template_id_6cd15634___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./GridFlexOrder.vue?vue&type=template&id=6cd15634& */ "./resources/js/src/views/ui-elements/grid/vuesax/GridFlexOrder.vue?vue&type=template&id=6cd15634&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _GridFlexOrder_vue_vue_type_template_id_6cd15634___WEBPACK_IMPORTED_MODULE_0__["render"],
  _GridFlexOrder_vue_vue_type_template_id_6cd15634___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/ui-elements/grid/vuesax/GridFlexOrder.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/GridFlexOrder.vue?vue&type=template&id=6cd15634&":
/*!*********************************************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/GridFlexOrder.vue?vue&type=template&id=6cd15634& ***!
  \*********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GridFlexOrder_vue_vue_type_template_id_6cd15634___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./GridFlexOrder.vue?vue&type=template&id=6cd15634& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridFlexOrder.vue?vue&type=template&id=6cd15634&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GridFlexOrder_vue_vue_type_template_id_6cd15634___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GridFlexOrder_vue_vue_type_template_id_6cd15634___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/GridOverview.vue":
/*!*************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/GridOverview.vue ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _GridOverview_vue_vue_type_template_id_379a692c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./GridOverview.vue?vue&type=template&id=379a692c& */ "./resources/js/src/views/ui-elements/grid/vuesax/GridOverview.vue?vue&type=template&id=379a692c&");
/* harmony import */ var _GridOverview_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./GridOverview.vue?vue&type=script&lang=js& */ "./resources/js/src/views/ui-elements/grid/vuesax/GridOverview.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _GridOverview_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _GridOverview_vue_vue_type_template_id_379a692c___WEBPACK_IMPORTED_MODULE_0__["render"],
  _GridOverview_vue_vue_type_template_id_379a692c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/ui-elements/grid/vuesax/GridOverview.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/GridOverview.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/GridOverview.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_GridOverview_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./GridOverview.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridOverview.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_GridOverview_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/GridOverview.vue?vue&type=template&id=379a692c&":
/*!********************************************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/GridOverview.vue?vue&type=template&id=379a692c& ***!
  \********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GridOverview_vue_vue_type_template_id_379a692c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./GridOverview.vue?vue&type=template&id=379a692c& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridOverview.vue?vue&type=template&id=379a692c&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GridOverview_vue_vue_type_template_id_379a692c___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GridOverview_vue_vue_type_template_id_379a692c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/GridResponsiveLayout.vue":
/*!*********************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/GridResponsiveLayout.vue ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _GridResponsiveLayout_vue_vue_type_template_id_0b3fbf22___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./GridResponsiveLayout.vue?vue&type=template&id=0b3fbf22& */ "./resources/js/src/views/ui-elements/grid/vuesax/GridResponsiveLayout.vue?vue&type=template&id=0b3fbf22&");
/* harmony import */ var _GridResponsiveLayout_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./GridResponsiveLayout.vue?vue&type=script&lang=js& */ "./resources/js/src/views/ui-elements/grid/vuesax/GridResponsiveLayout.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _GridResponsiveLayout_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _GridResponsiveLayout_vue_vue_type_template_id_0b3fbf22___WEBPACK_IMPORTED_MODULE_0__["render"],
  _GridResponsiveLayout_vue_vue_type_template_id_0b3fbf22___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/ui-elements/grid/vuesax/GridResponsiveLayout.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/GridResponsiveLayout.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/GridResponsiveLayout.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_GridResponsiveLayout_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./GridResponsiveLayout.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridResponsiveLayout.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_GridResponsiveLayout_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/GridResponsiveLayout.vue?vue&type=template&id=0b3fbf22&":
/*!****************************************************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/GridResponsiveLayout.vue?vue&type=template&id=0b3fbf22& ***!
  \****************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GridResponsiveLayout_vue_vue_type_template_id_0b3fbf22___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./GridResponsiveLayout.vue?vue&type=template&id=0b3fbf22& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridResponsiveLayout.vue?vue&type=template&id=0b3fbf22&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GridResponsiveLayout_vue_vue_type_template_id_0b3fbf22___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GridResponsiveLayout_vue_vue_type_template_id_0b3fbf22___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/GridVuesax.vue":
/*!***********************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/GridVuesax.vue ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _GridVuesax_vue_vue_type_template_id_99cea156___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./GridVuesax.vue?vue&type=template&id=99cea156& */ "./resources/js/src/views/ui-elements/grid/vuesax/GridVuesax.vue?vue&type=template&id=99cea156&");
/* harmony import */ var _GridVuesax_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./GridVuesax.vue?vue&type=script&lang=js& */ "./resources/js/src/views/ui-elements/grid/vuesax/GridVuesax.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _GridVuesax_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./GridVuesax.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/src/views/ui-elements/grid/vuesax/GridVuesax.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _GridVuesax_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _GridVuesax_vue_vue_type_template_id_99cea156___WEBPACK_IMPORTED_MODULE_0__["render"],
  _GridVuesax_vue_vue_type_template_id_99cea156___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/ui-elements/grid/vuesax/GridVuesax.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/GridVuesax.vue?vue&type=script&lang=js&":
/*!************************************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/GridVuesax.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_GridVuesax_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./GridVuesax.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridVuesax.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_GridVuesax_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/GridVuesax.vue?vue&type=style&index=0&lang=scss&":
/*!*********************************************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/GridVuesax.vue?vue&type=style&index=0&lang=scss& ***!
  \*********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_GridVuesax_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/style-loader!../../../../../../../node_modules/css-loader!../../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../node_modules/postcss-loader/src??ref--8-2!../../../../../../../node_modules/sass-loader/dist/cjs.js??ref--8-3!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./GridVuesax.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridVuesax.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_GridVuesax_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_GridVuesax_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_GridVuesax_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_GridVuesax_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/GridVuesax.vue?vue&type=template&id=99cea156&":
/*!******************************************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/GridVuesax.vue?vue&type=template&id=99cea156& ***!
  \******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GridVuesax_vue_vue_type_template_id_99cea156___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./GridVuesax.vue?vue&type=template&id=99cea156& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/GridVuesax.vue?vue&type=template&id=99cea156&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GridVuesax_vue_vue_type_template_id_99cea156___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_GridVuesax_vue_vue_type_template_id_99cea156___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentBottom.vue":
/*!***********************************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentBottom.vue ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _FlexAlignmentBottom_vue_vue_type_template_id_712b9680___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FlexAlignmentBottom.vue?vue&type=template&id=712b9680& */ "./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentBottom.vue?vue&type=template&id=712b9680&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _FlexAlignmentBottom_vue_vue_type_template_id_712b9680___WEBPACK_IMPORTED_MODULE_0__["render"],
  _FlexAlignmentBottom_vue_vue_type_template_id_712b9680___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentBottom.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentBottom.vue?vue&type=template&id=712b9680&":
/*!******************************************************************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentBottom.vue?vue&type=template&id=712b9680& ***!
  \******************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexAlignmentBottom_vue_vue_type_template_id_712b9680___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FlexAlignmentBottom.vue?vue&type=template&id=712b9680& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentBottom.vue?vue&type=template&id=712b9680&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexAlignmentBottom_vue_vue_type_template_id_712b9680___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexAlignmentBottom_vue_vue_type_template_id_712b9680___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentCenter.vue":
/*!***********************************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentCenter.vue ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _FlexAlignmentCenter_vue_vue_type_template_id_70f641ea___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FlexAlignmentCenter.vue?vue&type=template&id=70f641ea& */ "./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentCenter.vue?vue&type=template&id=70f641ea&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _FlexAlignmentCenter_vue_vue_type_template_id_70f641ea___WEBPACK_IMPORTED_MODULE_0__["render"],
  _FlexAlignmentCenter_vue_vue_type_template_id_70f641ea___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentCenter.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentCenter.vue?vue&type=template&id=70f641ea&":
/*!******************************************************************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentCenter.vue?vue&type=template&id=70f641ea& ***!
  \******************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexAlignmentCenter_vue_vue_type_template_id_70f641ea___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FlexAlignmentCenter.vue?vue&type=template&id=70f641ea& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentCenter.vue?vue&type=template&id=70f641ea&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexAlignmentCenter_vue_vue_type_template_id_70f641ea___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexAlignmentCenter_vue_vue_type_template_id_70f641ea___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentTop.vue":
/*!********************************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentTop.vue ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _FlexAlignmentTop_vue_vue_type_template_id_3cb80510___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FlexAlignmentTop.vue?vue&type=template&id=3cb80510& */ "./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentTop.vue?vue&type=template&id=3cb80510&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _FlexAlignmentTop_vue_vue_type_template_id_3cb80510___WEBPACK_IMPORTED_MODULE_0__["render"],
  _FlexAlignmentTop_vue_vue_type_template_id_3cb80510___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentTop.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentTop.vue?vue&type=template&id=3cb80510&":
/*!***************************************************************************************************************************!*\
  !*** ./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentTop.vue?vue&type=template&id=3cb80510& ***!
  \***************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexAlignmentTop_vue_vue_type_template_id_3cb80510___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FlexAlignmentTop.vue?vue&type=template&id=3cb80510& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui-elements/grid/vuesax/flex-alignment/FlexAlignmentTop.vue?vue&type=template&id=3cb80510&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexAlignmentTop_vue_vue_type_template_id_3cb80510___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexAlignmentTop_vue_vue_type_template_id_3cb80510___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);